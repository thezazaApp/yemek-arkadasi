import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import styles from './UserCard.module.css';

const UserCard = ({ user, onLike, onPass }) => {
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [showDetails, setShowDetails] = useState(false);

  const verificationBadges = {
    bronze: { icon: '🥉', label: 'Bronz', color: '#CD7F32' },
    silver: { icon: '🥈', label: 'Gümüş', color: '#C0C0C0' },
    gold: { icon: '🥇', label: 'Altın', color: '#FFD700' },
    platinum: { icon: '💎', label: 'Platin', color: '#E5E4E2' },
  };

  const badge = verificationBadges[user.verification_level] || verificationBadges.bronze;

  const photos = user.photos || [
    user.avatar_url || 'https://via.placeholder.com/400x500?text=No+Photo'
  ];

  const handleNextPhoto = () => {
    if (currentPhotoIndex < photos.length - 1) {
      setCurrentPhotoIndex(prev => prev + 1);
    }
  };

  const handlePrevPhoto = () => {
    if (currentPhotoIndex > 0) {
      setCurrentPhotoIndex(prev => prev - 1);
    }
  };

  return (
    <div className={styles.userCard}>
      {/* Fotoğraf Galerisi */}
      <div className={styles.photoGallery}>
        <img
          src={photos[currentPhotoIndex]}
          alt={user.full_name}
          className={styles.mainPhoto}
        />
        
        {/* Fotoğraf Navigasyonu */}
        {photos.length > 1 && (
          <>
            <button
              className={`${styles.photoNav} ${styles.prev}`}
              onClick={handlePrevPhoto}
              disabled={currentPhotoIndex === 0}
            >
              ‹
            </button>
            <button
              className={`${styles.photoNav} ${styles.next}`}
              onClick={handleNextPhoto}
              disabled={currentPhotoIndex === photos.length - 1}
            >
              ›
            </button>
            
            {/* Fotoğraf İndikatörleri */}
            <div className={styles.photoIndicators}>
              {photos.map((_, index) => (
                <span
                  key={index}
                  className={`${styles.indicator} ${index === currentPhotoIndex ? styles.active : ''}`}
                  onClick={() => setCurrentPhotoIndex(index)}
                />
              ))}
            </div>
          </>
        )}

        {/* Doğrulama Rozeti */}
        <div 
          className={styles.verificationBadge}
          style={{ backgroundColor: badge.color }}
        >
          <span>{badge.icon}</span>
          <span>{badge.label}</span>
        </div>

        {/* Online Durumu */}
        {user.is_online && (
          <div className={styles.onlineIndicator}>
            <span className={styles.onlineDot}></span>
            <span>Çevrimiçi</span>
          </div>
        )}
      </div>

      {/* Kullanıcı Bilgileri */}
      <div className={styles.userInfo}>
        <div className={styles.basicInfo}>
          <h2>
            {user.full_name}, {user.age}
          </h2>
          <button
            className={styles.infoToggle}
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? '▲' : '▼'}
          </button>
        </div>

        <div className={styles.location}>
          <span>📍</span>
          <span>{user.location_city || 'Konum belirtilmemiş'}</span>
          <span className={styles.distance}>
            {user.distance ? `${user.distance} km uzakta` : ''}
          </span>
        </div>

        {/* Detaylı Bilgiler */}
        <AnimatePresence>
          {showDetails && (
            <motion.div
              className={styles.details}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
            >
              <p className={styles.bio}>{user.bio || 'Henüz biyografi eklenmemiş.'}</p>
              
              <div className={styles.preferences}>
                <div className={styles.prefItem}>
                  <span>🍽️</span>
                  <span>Mutfak Tercihleri:</span>
                  <span>
                    {user.food_preferences?.mutfaklar?.join(', ') || 'Belirtilmemiş'}
                  </span>
                </div>
                <div className={styles.prefItem}>
                  <span>💰</span>
                  <span>Bütçe:</span>
                  <span>{user.budget_range || 'Belirtilmemiş'}</span>
                </div>
                <div className={styles.prefItem}>
                  <span>💬</span>
                  <span>Sohbet Tarzı:</span>
                  <span>{user.conversation_style || 'Belirtilmemiş'}</span>
                </div>
              </div>

              <div className={styles.rating}>
                <div className={styles.ratingStars}>
                  {[1, 2, 3, 4, 5].map(star => (
                    <span
                      key={star}
                      className={star <= (user.rating_average || 0) ? styles.filled : ''}
                    >
                      ★
                    </span>
                  ))}
                </div>
                <span className={styles.ratingText}>
                  {user.rating_average?.toFixed(1) || '0.0'} ({user.total_reviews || 0} değerlendirme)
                </span>
              </div>

              <div className={styles.mealStats}>
                <span>🍴 {user.total_meals || 0} başarılı buluşma</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Aksiyon Butonları */}
      <div className={styles.actions}>
        <button
          className={`${styles.actionButton} ${styles.pass}`}
          onClick={onPass}
        >
          ✕
        </button>
        <button
          className={`${styles.actionButton} ${styles.like}`}
          onClick={onLike}
        >
          ♥
        </button>
      </div>

      {/* Güvenlik Uyarısı */}
      {user.verification_level === 'bronze' && (
        <div className={styles.safetyWarning}>
          <span>⚠️</span>
          <span>Bu kullanıcı temel doğrulama seviyesinde</span>
        </div>
      )}
    </div>
  );
};

export default UserCard;