import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import { useSocket } from '../../context/SocketContext';
import styles from './EmergencyButton.module.css';

const EmergencyButton = ({ meetingId, compact = false }) => {
  const [isActivated, setIsActivated] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);
  const [location, setLocation] = useState(null);
  const { triggerEmergency, isConnected } = useSocket();

  useEffect(() => {
    let timer;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    } else if (countdown === 0 && isActivated) {
      handleEmergencyConfirmed();
    }
    return () => clearTimeout(timer);
  }, [countdown, isActivated]);

  const handlePanicClick = () => {
    if (compact) {
      setShowConfirm(true);
    } else {
      setCountdown(3);
      setIsActivated(true);
      toast('Acil durum bildirimi 3 saniye içinde gönderilecek', {
        icon: '⚠️',
        duration: 3000,
      });
    }
  };

  const handleCancelEmergency = () => {
    setIsActivated(false);
    setCountdown(0);
    setShowConfirm(false);
    toast.success('Acil durum iptal edildi');
  };

  const handleEmergencyConfirmed = async () => {
    try {
      // Konum al
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setLocation({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            });
          },
          (error) => {
            console.error('Konum alınamadı:', error);
          }
        );
      }

      // Acil durumu tetikle
      if (isConnected) {
        triggerEmergency(meetingId, location?.latitude, location?.longitude);
      }

      toast.success('Acil durum bildirimi gönderildi! Güvenilir kişilerinize haber veriliyor.', {
        icon: '🚨',
        duration: 6000,
      });

      setIsActivated(false);
      setCountdown(0);
      setShowConfirm(false);
    } catch (error) {
      toast.error('Acil durum bildirimi gönderilemedi');
      setIsActivated(false);
      setCountdown(0);
    }
  };

  const handleConfirmEmergency = () => {
    setShowConfirm(false);
    handleEmergencyConfirmed();
  };

  if (compact) {
    return (
      <>
        <button
          className={`${styles.emergencyButton} ${styles.compact}`}
          onClick={handlePanicClick}
          title="Acil Durum Butonu"
        >
          <span>🆘</span>
        </button>

        <AnimatePresence>
          {showConfirm && (
            <motion.div
              className={styles.confirmOverlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className={styles.confirmDialog}
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.9 }}
              >
                <h3>Acil Durum Bildirimi</h3>
                <p>Acil durum bildirimi göndermek istediğinize emin misiniz?</p>
                <p className={styles.warningText}>
                  Güvenilir kişilerinize konumunuz gönderilecektir.
                </p>
                <div className={styles.confirmActions}>
                  <button 
                    className={styles.cancelButton}
                    onClick={() => setShowConfirm(false)}
                  >
                    İptal
                  </button>
                  <button 
                    className={styles.confirmButton}
                    onClick={handleConfirmEmergency}
                  >
                    Evet, Gönder
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }

  return (
    <div className={styles.emergencyContainer}>
      <button
        className={`${styles.emergencyButton} ${isActivated ? styles.activated : ''}`}
        onClick={isActivated ? handleCancelEmergency : handlePanicClick}
      >
        <span className={styles.emergencyIcon}>
          {isActivated ? '⚠️' : '🆘'}
        </span>
        <span className={styles.emergencyText}>
          {isActivated ? `İptal (${countdown}s)` : 'Acil Durum'}
        </span>
      </button>

      {isActivated && (
        <motion.div
          className={styles.countdownBar}
          initial={{ width: '100%' }}
          animate={{ width: '0%' }}
          transition={{ duration: 3, ease: 'linear' }}
        />
      )}
    </div>
  );
};

export default EmergencyButton;