import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../context/AuthContext';
import EmergencyButton from './EmergencyButton';
import styles from './Navbar.module.css';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: '/dashboard', label: 'Keşfet', icon: '🔍' },
    { path: '/matches', label: 'Eşleşmeler', icon: '💕' },
    { path: '/messages', label: 'Mesajlar', icon: '💬' },
    { path: '/meetings', label: 'Randevular', icon: '📅' },
    { path: '/restaurants', label: 'Restoranlar', icon: '🍽️' },
  ];

  const handleLogout = () => {
    logout();
    setIsProfileDropdownOpen(false);
    setIsMobileMenuOpen(false);
  };

  const getVerificationBadge = (level) => {
    const badges = {
      bronze: { icon: '🥉', color: '#CD7F32' },
      silver: { icon: '🥈', color: '#C0C0C0' },
      gold: { icon: '🥇', color: '#FFD700' },
      platinum: { icon: '💎', color: '#E5E4E2' },
    };
    return badges[level] || badges.bronze;
  };

  const badge = getVerificationBadge(user?.verification_level);

  return (
    <>
      <nav className={styles.navbar}>
        <div className={styles.navbarContent}>
          {/* Logo */}
          <Link to="/dashboard" className={styles.logo}>
            <span className={styles.logoIcon}>🍽️</span>
            <span className={styles.logoText}>Yemek Arkadaşı</span>
          </Link>

          {/* Desktop Navigation */}
          <div className={styles.desktopNav}>
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`${styles.navLink} ${
                  location.pathname === item.path ? styles.active : ''
                }`}
              >
                <span className={styles.navIcon}>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </div>

          {/* Right Section */}
          <div className={styles.rightSection}>
            {/* Emergency Button */}
            <EmergencyButton />

            {/* Notifications */}
            <button className={styles.iconButton}>
              <span className={styles.notificationIcon}>🔔</span>
              <span className={styles.notificationBadge}>3</span>
            </button>

            {/* Profile Dropdown */}
            <div className={styles.profileDropdown}>
              <button
                className={styles.profileButton}
                onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
              >
                <div className={styles.avatar}>
                  {user?.avatar_url ? (
                    <img src={user.avatar_url} alt={user.full_name} />
                  ) : (
                    <span>{user?.full_name?.charAt(0)}</span>
                  )}
                </div>
                <span className={styles.verificationBadge} style={{ color: badge.color }}>
                  {badge.icon}
                </span>
              </button>

              <AnimatePresence>
                {isProfileDropdownOpen && (
                  <motion.div
                    className={styles.dropdownMenu}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                  >
                    <Link
                      to="/profile"
                      className={styles.dropdownItem}
                      onClick={() => setIsProfileDropdownOpen(false)}
                    >
                      <span>👤</span> Profilim
                    </Link>
                    <Link
                      to="/verification"
                      className={styles.dropdownItem}
                      onClick={() => setIsProfileDropdownOpen(false)}
                    >
                      <span>✅</span> Doğrulama
                    </Link>
                    <Link
                      to="/settings"
                      className={styles.dropdownItem}
                      onClick={() => setIsProfileDropdownOpen(false)}
                    >
                      <span>⚙️</span> Ayarlar
                    </Link>
                    <div className={styles.dropdownDivider} />
                    <button
                      className={styles.dropdownItem}
                      onClick={handleLogout}
                    >
                      <span>🚪</span> Çıkış Yap
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Mobile Menu Button */}
            <button
              className={styles.mobileMenuButton}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            className={styles.mobileMenu}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween' }}
          >
            <div className={styles.mobileMenuHeader}>
              <h3>Menü</h3>
              <button onClick={() => setIsMobileMenuOpen(false)}>✕</button>
            </div>
            
            <div className={styles.mobileMenuContent}>
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={styles.mobileNavLink}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <span>{item.icon}</span>
                  <span>{item.label}</span>
                </Link>
              ))}
              
              <div className={styles.mobileMenuDivider} />
              
              <Link
                to="/profile"
                className={styles.mobileNavLink}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <span>👤</span>
                <span>Profilim</span>
              </Link>
              
              <Link
                to="/settings"
                className={styles.mobileNavLink}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <span>⚙️</span>
                <span>Ayarlar</span>
              </Link>
              
              <button
                className={styles.mobileNavLink}
                onClick={handleLogout}
              >
                <span>🚪</span>
                <span>Çıkış Yap</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;