import React from 'react';
import styles from './ErrorBoundary.module.css';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null, 
      errorInfo: null 
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo
    });

    // Hata loglama servisine gönder
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    // Burada Sentry, LogRocket gibi servislere gönderebilirsiniz
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    window.location.href = '/';
  };

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className={styles.errorContainer}>
          <div className={styles.errorContent}>
            <div className={styles.errorIcon}>😕</div>
            <h1>Bir Şeyler Yanlış Gitti</h1>
            <p>Beklenmeyen bir hata oluştu. Lütfen tekrar deneyin.</p>
            
            {process.env.NODE_ENV === 'development' && this.state.error && (
              <details className={styles.errorDetails}>
                <summary>Hata Detayları</summary>
                <pre>{this.state.error.toString()}</pre>
                <pre>{this.state.errorInfo?.componentStack}</pre>
              </details>
            )}

            <div className={styles.errorActions}>
              <button onClick={this.handleReload} className={styles.primaryButton}>
                Sayfayı Yenile
              </button>
              <button onClick={this.handleReset} className={styles.secondaryButton}>
                Ana Sayfaya Dön
              </button>
            </div>

            <div className={styles.errorFooter}>
              <p>
                Sorun devam ederse{' '}
                <a href="mailto:destek@yemekarkadasi.com">destek ekibimizle</a> iletişime geçin.
              </p>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;