import React from 'react';
import styles from './LoadingSkeleton.module.css';

const LoadingSkeleton = ({ type = 'card', count = 1 }) => {
  const renderSkeleton = () => {
    switch (type) {
      case 'user-card':
        return (
          <div className={styles.userCardSkeleton}>
            <div className={styles.skeletonImage} />
            <div className={styles.skeletonContent}>
              <div className={styles.skeletonTitle} />
              <div className={styles.skeletonText} />
              <div className={styles.skeletonText} />
            </div>
          </div>
        );

      case 'profile':
        return (
          <div className={styles.profileSkeleton}>
            <div className={styles.skeletonCover} />
            <div className={styles.skeletonAvatar} />
            <div className={styles.skeletonProfileInfo}>
              <div className={styles.skeletonTitle} />
              <div className={styles.skeletonText} />
              <div className={styles.skeletonText} />
            </div>
          </div>
        );

      case 'messages':
        return (
          <div className={styles.messagesSkeleton}>
            <div className={styles.skeletonSidebar}>
              {[1, 2, 3, 4, 5].map(i => (
                <div key={i} className={styles.skeletonMatchItem}>
                  <div className={styles.skeletonAvatarSmall} />
                  <div className={styles.skeletonMatchInfo}>
                    <div className={styles.skeletonTitle} />
                    <div className={styles.skeletonTextSmall} />
                  </div>
                </div>
              ))}
            </div>
            <div className={styles.skeletonChat}>
              <div className={styles.skeletonChatHeader} />
              <div className={styles.skeletonMessages}>
                {[1, 2, 3].map(i => (
                  <div key={i} className={styles.skeletonMessage}>
                    <div className={styles.skeletonMessageBubble} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'restaurant':
        return (
          <div className={styles.restaurantSkeleton}>
            <div className={styles.skeletonRestaurantImage} />
            <div className={styles.skeletonRestaurantInfo}>
              <div className={styles.skeletonTitle} />
              <div className={styles.skeletonText} />
              <div className={styles.skeletonRating} />
            </div>
          </div>
        );

      case 'meetings':
        return (
          <div className={styles.meetingSkeleton}>
            <div className={styles.skeletonMeetingHeader}>
              <div className={styles.skeletonAvatarSmall} />
              <div className={styles.skeletonMeetingTitle}>
                <div className={styles.skeletonTitle} />
                <div className={styles.skeletonTextSmall} />
              </div>
            </div>
            <div className={styles.skeletonMeetingDetails}>
              <div className={styles.skeletonText} />
              <div className={styles.skeletonText} />
            </div>
          </div>
        );

      default:
        return (
          <div className={styles.cardSkeleton}>
            <div className={styles.skeletonImage} />
            <div className={styles.skeletonContent}>
              <div className={styles.skeletonTitle} />
              <div className={styles.skeletonText} />
            </div>
          </div>
        );
    }
  };

  return (
    <div className={styles.skeletonContainer}>
      {Array.from({ length: count }).map((_, index) => (
        <div key={index} className={styles.skeletonWrapper}>
          {renderSkeleton()}
        </div>
      ))}
    </div>
  );
};

export default LoadingSkeleton;