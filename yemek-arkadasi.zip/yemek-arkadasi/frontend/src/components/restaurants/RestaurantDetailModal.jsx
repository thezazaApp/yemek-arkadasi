import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import api from '../../utils/api';
import styles from './RestaurantDetailModal.module.css';

const RestaurantDetailModal = ({ restaurant, onClose, userLocation }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('info'); // info, menu, reviews, photos
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [guestCount, setGuestCount] = useState(2);

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return (R * c).toFixed(1);
  };

  const distance = userLocation 
    ? calculateDistance(
        userLocation.lat, 
        userLocation.lng, 
        restaurant.latitude, 
        restaurant.longitude
      )
    : null;

  const priceRangeLabels = {
    'ekonomik': '₺ (Ekonomik)',
    'orta': '₺₺ (Orta)',
    'pahalı': '₺₺₺ (Pahalı)',
  };

  const reservationMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.post('/restaurants/reservation', {
        restaurant_id: restaurant.id,
        ...data,
      });
      return response.data.data;
    },
    onSuccess: () => {
      toast.success('Rezervasyon talebi oluşturuldu!');
      onClose();
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Rezervasyon oluşturulamadı');
    },
  });

  const handleReservation = () => {
    if (!selectedDate || !selectedTime) {
      toast.error('Lütfen tarih ve saat seçin');
      return;
    }

    reservationMutation.mutate({
      date: selectedDate,
      time: selectedTime,
      guests: guestCount,
    });
  };

  const sampleMenu = [
    { category: 'Başlangıçlar', items: [
      { name: 'Mercimek Çorbası', price: 85 },
      { name: 'Sigara Böreği', price: 95 },
      { name: 'Humus', price: 110 },
    ]},
    { category: 'Ana Yemekler', items: [
      { name: 'Izgara Köfte', price: 245 },
      { name: 'Tavuk Şiş', price: 225 },
      { name: 'Et Güveç', price: 285 },
    ]},
    { category: 'Tatlılar', items: [
      { name: 'Künefe', price: 120 },
      { name: 'Sütlaç', price: 85 },
      { name: 'Baklava', price: 140 },
    ]},
  ];

  const sampleReviews = [
    { id: 1, user: 'Ahmet Y.', rating: 5, comment: 'Harika bir deneyim! Yemekler çok lezzetliydi.', date: '2024-01-15' },
    { id: 2, user: 'Ayşe K.', rating: 4, comment: 'Servis biraz yavaştı ama yemekler güzeldi.', date: '2024-01-10' },
    { id: 3, user: 'Mehmet D.', rating: 5, comment: 'Kesinlikle tavsiye ederim. Atmosfer çok hoş.', date: '2024-01-05' },
  ];

  return (
    <motion.div
      className={styles.modalOverlay}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className={styles.modal}
        initial={{ scale: 0.9, y: 50, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.9, y: 50, opacity: 0 }}
        onClick={e => e.stopPropagation()}
      >
        <button className={styles.closeButton} onClick={onClose}>✕</button>

        {/* Restoran Görseli */}
        <div className={styles.restaurantImage}>
          <img 
            src={restaurant.image_url || 'https://via.placeholder.com/800x400?text=Restaurant'} 
            alt={restaurant.name} 
          />
          <div className={styles.imageOverlay}>
            <h2>{restaurant.name}</h2>
            <div className={styles.quickInfo}>
              <span>⭐ {restaurant.rating?.toFixed(1)}</span>
              <span>🍽️ {restaurant.cuisine_type}</span>
              <span>💰 {priceRangeLabels[restaurant.price_range]}</span>
              {distance && <span>📍 {distance} km</span>}
            </div>
          </div>
        </div>

        {/* Tab Navigasyonu */}
        <div className={styles.tabs}>
          <button 
            className={`${styles.tab} ${activeTab === 'info' ? styles.active : ''}`}
            onClick={() => setActiveTab('info')}
          >
            Bilgiler
          </button>
          <button 
            className={`${styles.tab} ${activeTab === 'menu' ? styles.active : ''}`}
            onClick={() => setActiveTab('menu')}
          >
            Menü
          </button>
          <button 
            className={`${styles.tab} ${activeTab === 'reviews' ? styles.active : ''}`}
            onClick={() => setActiveTab('reviews')}
          >
            Yorumlar
          </button>
          <button 
            className={`${styles.tab} ${activeTab === 'photos' ? styles.active : ''}`}
            onClick={() => setActiveTab('photos')}
          >
            Fotoğraflar
          </button>
        </div>

        {/* Tab İçeriği */}
        <div className={styles.tabContent}>
          {activeTab === 'info' && (
            <div className={styles.infoTab}>
              <div className={styles.infoSection}>
                <h3>📍 Adres</h3>
                <p>{restaurant.address}</p>
              </div>

              <div className={styles.infoSection}>
                <h3>📞 İletişim</h3>
                <p>{restaurant.phone || 'İletişim bilgisi bulunmuyor'}</p>
                {restaurant.website && (
                  <a href={restaurant.website} target="_blank" rel="noopener noreferrer">
                    Web Sitesini Ziyaret Et
                  </a>
                )}
              </div>

              <div className={styles.infoSection}>
                <h3>⏰ Çalışma Saatleri</h3>
                <div className={styles.openingHours}>
                  <p>Pazartesi - Cuma: 11:00 - 23:00</p>
                  <p>Cumartesi - Pazar: 10:00 - 00:00</p>
                </div>
              </div>

              <div className={styles.infoSection}>
                <h3>✨ Özellikler</h3>
                <div className={styles.features}>
                  <span>🍷 Alkollü İçecekler</span>
                  <span>🚗 Otopark</span>
                  <span>👨‍👩‍👧‍👦 Aile Dostu</span>
                  <span>🌿 Vejetaryen Seçenekler</span>
                  <span>💳 Kredi Kartı</span>
                  <span>📶 WiFi</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'menu' && (
            <div className={styles.menuTab}>
              {sampleMenu.map((section, index) => (
                <div key={index} className={styles.menuSection}>
                  <h3>{section.category}</h3>
                  <div className={styles.menuItems}>
                    {section.items.map((item, idx) => (
                      <div key={idx} className={styles.menuItem}>
                        <span className={styles.itemName}>{item.name}</span>
                        <span className={styles.itemPrice}>{item.price} ₺</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              <p className={styles.menuNote}>
                * Menü fiyatları örnek amaçlıdır, değişiklik gösterebilir.
              </p>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className={styles.reviewsTab}>
              <div className={styles.reviewsSummary}>
                <div className={styles.averageRating}>
                  <span className={styles.ratingNumber}>{restaurant.rating?.toFixed(1)}</span>
                  <div className={styles.ratingStars}>
                    {'★'.repeat(Math.round(restaurant.rating || 0))}
                    {'☆'.repeat(5 - Math.round(restaurant.rating || 0))}
                  </div>
                  <span className={styles.reviewCount}>{sampleReviews.length} yorum</span>
                </div>
              </div>

              <div className={styles.reviewsList}>
                {sampleReviews.map(review => (
                  <div key={review.id} className={styles.reviewCard}>
                    <div className={styles.reviewHeader}>
                      <span className={styles.reviewerName}>{review.user}</span>
                      <span className={styles.reviewRating}>
                        {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}
                      </span>
                      <span className={styles.reviewDate}>{review.date}</span>
                    </div>
                    <p className={styles.reviewComment}>{review.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'photos' && (
            <div className={styles.photosTab}>
              <div className={styles.photoGrid}>
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <div key={i} className={styles.photoItem}>
                    <img 
                      src={`https://via.placeholder.com/300x200?text=Photo+${i}`} 
                      alt={`Restaurant ${i}`} 
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Rezervasyon Paneli */}
        <div className={styles.reservationPanel}>
          <h3>Rezervasyon Yap</h3>
          <div className={styles.reservationForm}>
            <div className={styles.formRow}>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
              <input
                type="time"
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
              />
              <select 
                value={guestCount}
                onChange={(e) => setGuestCount(parseInt(e.target.value))}
              >
                {[1, 2, 3, 4, 5, 6].map(n => (
                  <option key={n} value={n}>{n} Kişi</option>
                ))}
              </select>
            </div>
            <button 
              className={styles.reserveButton}
              onClick={handleReservation}
              disabled={reservationMutation.isLoading}
            >
              {reservationMutation.isLoading ? 'İşleniyor...' : 'Rezervasyon Yap'}
            </button>
          </div>
          <p className={styles.reservationNote}>
            * Rezervasyon onayı restoran tarafından yapılacaktır.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default RestaurantDetailModal;