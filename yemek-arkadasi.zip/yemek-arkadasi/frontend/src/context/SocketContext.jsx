import React, { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const SocketContext = createContext(null);

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within SocketProvider');
  }
  return context;
};

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState(new Set());
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated || !user) {
      if (socket) {
        socket.disconnect();
        setSocket(null);
      }
      return;
    }

    const token = localStorage.getItem('token');
    
    const newSocket = io(import.meta.env.VITE_API_URL || 'http://localhost:5000', {
      auth: { token },
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    newSocket.on('connect', () => {
      console.log('🟢 Socket bağlandı');
      setIsConnected(true);
    });

    newSocket.on('disconnect', () => {
      console.log('🔴 Socket bağlantısı kesildi');
      setIsConnected(false);
    });

    newSocket.on('user:online', ({ userId }) => {
      setOnlineUsers(prev => new Set(prev).add(userId));
    });

    newSocket.on('user:offline', ({ userId }) => {
      setOnlineUsers(prev => {
        const newSet = new Set(prev);
        newSet.delete(userId);
        return newSet;
      });
    });

    newSocket.on('message:received', (message) => {
      // Mesaj geldiğinde bildirim göster
      if (document.visibilityState === 'hidden') {
        toast.success('Yeni mesajınız var!', {
          icon: '💬',
        });
      }
    });

    newSocket.on('emergency:acknowledged', (data) => {
      toast.success(`Acil durum bildirimi alındı. ${data.contactsNotified} güvenilir kişiye haber veriliyor.`, {
        icon: '🚨',
        duration: 6000,
      });
    });

    newSocket.on('error', (error) => {
      toast.error(error.message || 'Bir hata oluştu');
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, [isAuthenticated, user]);

  const joinMatchRoom = (matchId) => {
    if (socket && isConnected) {
      socket.emit('room:join', { matchId });
    }
  };

  const sendMessage = (matchId, content, contentType = 'text') => {
    if (socket && isConnected) {
      socket.emit('message:send', { matchId, content, contentType });
      return true;
    }
    return false;
  };

  const markMessageRead = (messageId, matchId) => {
    if (socket && isConnected) {
      socket.emit('message:read', { messageId, matchId });
    }
  };

  const startTyping = (matchId) => {
    if (socket && isConnected) {
      socket.emit('typing:start', { matchId });
    }
  };

  const stopTyping = (matchId) => {
    if (socket && isConnected) {
      socket.emit('typing:stop', { matchId });
    }
  };

  const shareLocation = (matchId, latitude, longitude, shareType) => {
    if (socket && isConnected) {
      socket.emit('location:share', { matchId, latitude, longitude, shareType });
    }
  };

  const triggerEmergency = (meetingId, latitude, longitude) => {
    if (socket && isConnected) {
      socket.emit('emergency:panic', { meetingId, latitude, longitude });
    }
  };

  const value = {
    socket,
    isConnected,
    onlineUsers,
    joinMatchRoom,
    sendMessage,
    markMessageRead,
    startTyping,
    stopTyping,
    shareLocation,
    triggerEmergency,
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};