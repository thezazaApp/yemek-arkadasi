import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import Navbar from '../components/common/Navbar';
import UserCard from '../components/dashboard/UserCard';
import FilterBar from '../components/dashboard/FilterBar';
import UpcomingMeetings from '../components/dashboard/UpcomingMeetings';
import MatchStats from '../components/dashboard/MatchStats';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import api from '../utils/api';
import styles from './DashboardPage.module.css';

const DashboardPage = () => {
  const [filters, setFilters] = useState({
    distance: 10,
    cuisine: [],
    budget: 'farketmez',
    verificationLevel: 'bronze',
    ageRange: [18, 60],
  });

  const [currentUserIndex, setCurrentUserIndex] = useState(0);
  const [swipeDirection, setSwipeDirection] = useState(null);

  const { data: discoverUsers, isLoading, refetch } = useQuery({
    queryKey: ['discover', filters],
    queryFn: async () => {
      const response = await api.get('/users/discover', { params: filters });
      return response.data.data;
    },
  });

  const { data: upcomingMeetings } = useQuery({
    queryKey: ['upcoming-meetings'],
    queryFn: async () => {
      const response = await api.get('/meetings/upcoming');
      return response.data.data;
    },
  });

  const { data: stats } = useQuery({
    queryKey: ['match-stats'],
    queryFn: async () => {
      const response = await api.get('/users/stats');
      return response.data.data;
    },
  });

  const handleSwipe = async (direction, userId) => {
    setSwipeDirection(direction);
    
    try {
      if (direction === 'right') {
        await api.post(`/matches/like/${userId}`);
      } else {
        await api.post(`/matches/pass/${userId}`);
      }
    } catch (error) {
      console.error('Swipe error:', error);
    }

    setTimeout(() => {
      setCurrentUserIndex(prev => prev + 1);
      setSwipeDirection(null);
    }, 300);
  };

  const currentUser = discoverUsers?.[currentUserIndex];

  return (
    <div className={styles.dashboard}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.container}>
          {/* Sol Panel - Keşfet */}
          <section className={styles.discoverSection}>
            <FilterBar filters={filters} onFilterChange={setFilters} />
            
            <div className={styles.cardContainer}>
              {isLoading ? (
                <LoadingSkeleton type="user-card" />
              ) : currentUser ? (
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentUser.id}
                    className={styles.cardWrapper}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{
                      opacity: 0,
                      x: swipeDirection === 'right' ? 300 : -300,
                      rotate: swipeDirection === 'right' ? 20 : -20,
                      transition: { duration: 0.3 }
                    }}
                  >
                    <UserCard
                      user={currentUser}
                      onLike={() => handleSwipe('right', currentUser.id)}
                      onPass={() => handleSwipe('left', currentUser.id)}
                    />
                  </motion.div>
                </AnimatePresence>
              ) : (
                <div className={styles.noMoreUsers}>
                  <span>🎉</span>
                  <h3>Şimdilik bu kadar!</h3>
                  <p>Yeni kullanıcılar için daha sonra tekrar kontrol edin.</p>
                  <button onClick={() => refetch()} className={styles.refreshButton}>
                    Yenile
                  </button>
                </div>
              )}
            </div>
          </section>

          {/* Sağ Panel - İstatistikler ve Randevular */}
          <aside className={styles.sidePanel}>
            <MatchStats stats={stats} />
            <UpcomingMeetings meetings={upcomingMeetings} />
            
            {/* Güvenlik Hatırlatması */}
            <div className={styles.safetyReminder}>
              <span>🛡️</span>
              <div>
                <h4>Güvenlik Hatırlatması</h4>
                <p>İlk buluşmada halka açık yerleri tercih edin.</p>
              </div>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
};

export default DashboardPage;