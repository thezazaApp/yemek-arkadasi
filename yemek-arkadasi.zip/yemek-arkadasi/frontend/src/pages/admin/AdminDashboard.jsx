import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
} from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';
import toast from 'react-hot-toast';
import api from '../../utils/api';
import styles from './AdminDashboard.module.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedReport, setSelectedReport] = useState(null);
  const queryClient = useQueryClient();

  // İstatistikleri getir
  const { data: stats } = useQuery({
    queryKey: ['admin', 'stats'],
    queryFn: async () => {
      const response = await api.get('/admin/stats');
      return response.data.data;
    },
  });

  // Kullanıcıları getir
  const { data: users } = useQuery({
    queryKey: ['admin', 'users'],
    queryFn: async () => {
      const response = await api.get('/admin/users');
      return response.data.data;
    },
    enabled: activeTab === 'users',
  });

  // Raporları getir
  const { data: reports } = useQuery({
    queryKey: ['admin', 'reports'],
    queryFn: async () => {
      const response = await api.get('/admin/reports');
      return response.data.data;
    },
    enabled: activeTab === 'reports',
  });

  // İşlemler
  const suspendUserMutation = useMutation({
    mutationFn: async ({ userId, reason }) => {
      const response = await api.post(`/admin/users/${userId}/suspend`, { reason });
      return response.data;
    },
    onSuccess: () => {
      toast.success('Kullanıcı askıya alındı');
      queryClient.invalidateQueries(['admin', 'users']);
    },
  });

  const resolveReportMutation = useMutation({
    mutationFn: async ({ reportId, action }) => {
      const response = await api.post(`/admin/reports/${reportId}/resolve`, { action });
      return response.data;
    },
    onSuccess: () => {
      toast.success('Rapor çözümlendi');
      queryClient.invalidateQueries(['admin', 'reports']);
      setSelectedReport(null);
    },
  });

  const chartData = {
    usersByLevel: {
      labels: ['Bronz', 'Gümüş', 'Altın', 'Platin'],
      datasets: [{
        label: 'Kullanıcı Sayısı',
        data: [
          stats?.users_by_level?.bronze || 0,
          stats?.users_by_level?.silver || 0,
          stats?.users_by_level?.gold || 0,
          stats?.users_by_level?.platinum || 0,
        ],
        backgroundColor: ['#CD7F32', '#C0C0C0', '#FFD700', '#E5E4E2'],
      }],
    },
    meetingsByMonth: {
      labels: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran'],
      datasets: [{
        label: 'Buluşma Sayısı',
        data: stats?.meetings_by_month || [0, 0, 0, 0, 0, 0],
        borderColor: '#FF6B6B',
        backgroundColor: 'rgba(255, 107, 107, 0.1)',
        tension: 0.4,
      }],
    },
    reportsByType: {
      labels: ['Uygunsuz İçerik', 'Sahte Profil', 'Taciz', 'Diğer'],
      datasets: [{
        data: [
          stats?.reports_by_type?.inappropriate || 0,
          stats?.reports_by_type?.fake_profile || 0,
          stats?.reports_by_type?.harassment || 0,
          stats?.reports_by_type?.other || 0,
        ],
        backgroundColor: ['#E74C3C', '#F39C12', '#3498DB', '#95A5A6'],
      }],
    },
  };

  const statsCards = [
    { label: 'Toplam Kullanıcı', value: stats?.total_users || 0, icon: '👥', color: '#FF6B6B' },
    { label: 'Aktif Kullanıcı', value: stats?.active_users || 0, icon: '🟢', color: '#27AE60' },
    { label: 'Toplam Buluşma', value: stats?.total_meetings || 0, icon: '🍽️', color: '#4ECDC4' },
    { label: 'Bekleyen Rapor', value: stats?.pending_reports || 0, icon: '⚠️', color: '#F39C12' },
  ];

  return (
    <div className={styles.adminDashboard}>
      <header className={styles.adminHeader}>
        <h1>Admin Paneli</h1>
        <div className={styles.adminNav}>
          <button 
            className={`${styles.tabButton} ${activeTab === 'overview' ? styles.active : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            Genel Bakış
          </button>
          <button 
            className={`${styles.tabButton} ${activeTab === 'users' ? styles.active : ''}`}
            onClick={() => setActiveTab('users')}
          >
            Kullanıcılar
          </button>
          <button 
            className={`${styles.tabButton} ${activeTab === 'reports' ? styles.active : ''}`}
            onClick={() => setActiveTab('reports')}
          >
            Raporlar
            {stats?.pending_reports > 0 && (
              <span className={styles.badge}>{stats.pending_reports}</span>
            )}
          </button>
          <button 
            className={`${styles.tabButton} ${activeTab === 'analytics' ? styles.active : ''}`}
            onClick={() => setActiveTab('analytics')}
          >
            Analitik
          </button>
        </div>
      </header>

      <main className={styles.adminContent}>
        {/* Genel Bakış */}
        {activeTab === 'overview' && (
          <div className={styles.overviewTab}>
            <div className={styles.statsGrid}>
              {statsCards.map((stat, index) => (
                <motion.div
                  key={index}
                  className={styles.statCard}
                  style={{ borderTopColor: stat.color }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className={styles.statHeader}>
                    <span className={styles.statIcon}>{stat.icon}</span>
                    <span className={styles.statValue}>{stat.value.toLocaleString()}</span>
                  </div>
                  <span className={styles.statLabel}>{stat.label}</span>
                </motion.div>
              ))}
            </div>

            <div className={styles.chartsGrid}>
              <div className={styles.chartCard}>
                <h3>Kullanıcı Dağılımı</h3>
                <Pie data={chartData.usersByLevel} />
              </div>
              <div className={styles.chartCard}>
                <h3>Aylık Buluşma Trendi</h3>
                <Line data={chartData.meetingsByMonth} />
              </div>
            </div>

            <div className={styles.recentActivity}>
              <h3>Son Aktiviteler</h3>
              <div className={styles.activityList}>
                {stats?.recent_activities?.map((activity, index) => (
                  <div key={index} className={styles.activityItem}>
                    <span className={styles.activityIcon}>{activity.icon}</span>
                    <div className={styles.activityInfo}>
                      <p>{activity.description}</p>
                      <span className={styles.activityTime}>{activity.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Kullanıcılar */}
        {activeTab === 'users' && (
          <div className={styles.usersTab}>
            <div className={styles.usersHeader}>
              <div className={styles.searchBar}>
                <input type="text" placeholder="Kullanıcı ara..." />
                <button>🔍</button>
              </div>
              <div className={styles.filterButtons}>
                <select className={styles.filterSelect}>
                  <option value="">Tümü</option>
                  <option value="bronze">Bronz</option>
                  <option value="silver">Gümüş</option>
                  <option value="gold">Altın</option>
                  <option value="platinum">Platin</option>
                </select>
              </div>
            </div>

            <div className={styles.usersTable}>
              <table>
                <thead>
                  <tr>
                    <th>Kullanıcı</th>
                    <th>Seviye</th>
                    <th>Buluşma</th>
                    <th>Puan</th>
                    <th>Kayıt Tarihi</th>
                    <th>Durum</th>
                    <th>İşlemler</th>
                  </tr>
                </thead>
                <tbody>
                  {users?.map(user => (
                    <tr key={user.id}>
                      <td className={styles.userCell}>
                        <img src={user.avatar_url || 'https://via.placeholder.com/40'} alt="" />
                        <div>
                          <strong>{user.full_name}</strong>
                          <span>{user.email}</span>
                        </div>
                      </td>
                      <td>
                        <span className={`${styles.levelBadge} ${styles[user.verification_level]}`}>
                          {user.verification_level}
                        </span>
                      </td>
                      <td>{user.total_meals}</td>
                      <td>{user.rating_average?.toFixed(1)}</td>
                      <td>{new Date(user.created_at).toLocaleDateString('tr-TR')}</td>
                      <td>
                        <span className={`${styles.statusBadge} ${user.is_active ? styles.active : styles.inactive}`}>
                          {user.is_active ? 'Aktif' : 'Pasif'}
                        </span>
                      </td>
                      <td>
                        <div className={styles.actionButtons}>
                          <button className={styles.viewButton} title="Görüntüle">👁️</button>
                          <button 
                            className={styles.suspendButton} 
                            title="Askıya Al"
                            onClick={() => {
                              const reason = prompt('Askıya alma sebebi:');
                              if (reason) suspendUserMutation.mutate({ userId: user.id, reason });
                            }}
                          >
                            ⏸️
                          </button>
                          <button className={styles.warnButton} title="Uyar">⚠️</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Raporlar */}
        {activeTab === 'reports' && (
          <div className={styles.reportsTab}>
            <div className={styles.reportsLayout}>
              <div className={styles.reportsList}>
                <h3>Bekleyen Raporlar</h3>
                {reports?.map(report => (
                  <div 
                    key={report.id} 
                    className={`${styles.reportCard} ${selectedReport?.id === report.id ? styles.selected : ''}`}
                    onClick={() => setSelectedReport(report)}
                  >
                    <div className={styles.reportHeader}>
                      <span className={`${styles.reportType} ${styles[report.type]}`}>
                        {report.type_label}
                      </span>
                      <span className={styles.reportPriority}>
                        {report.priority === 'high' ? '🔴' : report.priority === 'medium' ? '🟡' : '🟢'}
                      </span>
                    </div>
                    <p className={styles.reportDescription}>{report.description}</p>
                    <div className={styles.reportMeta}>
                      <span>Bildiren: {report.reporter_name}</span>
                      <span>{new Date(report.created_at).toLocaleDateString('tr-TR')}</span>
                    </div>
                  </div>
                ))}
              </div>

              {selectedReport && (
                <div className={styles.reportDetail}>
                  <h3>Rapor Detayı</h3>
                  <div className={styles.reportDetailContent}>
                    <div className={styles.reportParties}>
                      <div className={styles.party}>
                        <strong>Bildiren:</strong>
                        <div className={styles.partyInfo}>
                          <img src={selectedReport.reporter_avatar} alt="" />
                          <span>{selectedReport.reporter_name}</span>
                        </div>
                      </div>
                      <div className={styles.party}>
                        <strong>Bildirilen:</strong>
                        <div className={styles.partyInfo}>
                          <img src={selectedReport.reported_avatar} alt="" />
                          <span>{selectedReport.reported_name}</span>
                        </div>
                      </div>
                    </div>

                    <div className={styles.reportEvidence}>
                      <strong>Açıklama:</strong>
                      <p>{selectedReport.description}</p>
                    </div>

                    <div className={styles.reportActions}>
                      <button 
                        className={styles.resolveButton}
                        onClick={() => resolveReportMutation.mutate({ 
                          reportId: selectedReport.id, 
                          action: 'resolve' 
                        })}
                      >
                        Çözümlendi
                      </button>
                      <button 
                        className={styles.warnButton}
                        onClick={() => resolveReportMutation.mutate({ 
                          reportId: selectedReport.id, 
                          action: 'warn' 
                        })}
                      >
                        Kullanıcıyı Uyar
                      </button>
                      <button 
                        className={styles.suspendButton}
                        onClick={() => resolveReportMutation.mutate({ 
                          reportId: selectedReport.id, 
                          action: 'suspend' 
                        })}
                      >
                        Askıya Al
                      </button>
                      <button 
                        className={styles.dismissButton}
                        onClick={() => resolveReportMutation.mutate({ 
                          reportId: selectedReport.id, 
                          action: 'dismiss' 
                        })}
                      >
                        Reddet
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Analitik */}
        {activeTab === 'analytics' && (
          <div className={styles.analyticsTab}>
            <div className={styles.chartsGrid}>
              <div className={styles.chartCard}>
                <h3>Kullanıcı Büyümesi</h3>
                <Line data={chartData.meetingsByMonth} />
              </div>
              <div className={styles.chartCard}>
                <h3>Rapor Dağılımı</h3>
                <Pie data={chartData.reportsByType} />
              </div>
              <div className={styles.chartCard}>
                <h3>Doğrulama Seviyeleri</h3>
                <Bar data={chartData.usersByLevel} />
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;