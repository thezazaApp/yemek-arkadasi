import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';
import Navbar from '../components/common/Navbar';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import EmergencyButton from '../components/common/EmergencyButton';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import styles from './MessagesPage.module.css';

const MessagesPage = () => {
  const { matchId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { socket, isConnected, joinMatchRoom, sendMessage, startTyping, stopTyping, shareLocation } = useSocket();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef(null);
  const [typingUsers, setTypingUsers] = useState(new Set());
  const [isTyping, setIsTyping] = useState(false);
  const typingTimeoutRef = useRef(null);

  const { register, handleSubmit, reset, watch } = useForm();
  const messageContent = watch('message', '');

  // Eşleşmeleri getir
  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ['matches'],
    queryFn: async () => {
      const response = await api.get('/matches');
      return response.data.data;
    },
  });

  const currentMatch = matches?.find(m => m.id === parseInt(matchId));
  const activeMatchId = matchId || matches?.[0]?.id;

  // Mesajları getir
  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ['messages', activeMatchId],
    queryFn: async () => {
      if (!activeMatchId) return [];
      const response = await api.get(`/messages/${activeMatchId}`);
      return response.data.data;
    },
    enabled: !!activeMatchId,
  });

  // Mesaj gönderme mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ matchId, content }) => {
      // Önce API'ye kaydet
      const response = await api.post('/messages', { match_id: matchId, content });
      return response.data.data;
    },
    onSuccess: (data, variables) => {
      // Socket üzerinden gönder
      sendMessage(variables.matchId, variables.content);
      queryClient.invalidateQueries(['messages', variables.matchId]);
      reset();
      setIsTyping(false);
    },
  });

  // Socket event'lerini dinle
  useEffect(() => {
    if (!socket || !activeMatchId) return;

    joinMatchRoom(activeMatchId);

    socket.on('message:received', (message) => {
      if (message.matchId === parseInt(activeMatchId)) {
        queryClient.invalidateQueries(['messages', activeMatchId]);
      }
    });

    socket.on('typing:update', ({ userId, isTyping }) => {
      setTypingUsers(prev => {
        const newSet = new Set(prev);
        if (isTyping) {
          newSet.add(userId);
        } else {
          newSet.delete(userId);
        }
        return newSet;
      });
    });

    socket.on('location:received', (location) => {
      toast.success(`${location.userId} konum paylaştı`);
      queryClient.invalidateQueries(['messages', activeMatchId]);
    });

    return () => {
      socket.off('message:received');
      socket.off('typing:update');
      socket.off('location:received');
    };
  }, [socket, activeMatchId, joinMatchRoom, queryClient]);

  // Mesajları otomatik kaydır
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Yazma durumunu yönet
  const handleTyping = () => {
    if (!isTyping && activeMatchId) {
      setIsTyping(true);
      startTyping(activeMatchId);
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      if (activeMatchId) {
        stopTyping(activeMatchId);
      }
      setIsTyping(false);
    }, 2000);
  };

  const onSubmit = (data) => {
    if (!data.message.trim() || !activeMatchId) return;
    
    sendMessageMutation.mutate({
      matchId: activeMatchId,
      content: data.message.trim(),
    });
  };

  const handleShareLocation = () => {
    if (!activeMatchId) return;

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          shareLocation(
            activeMatchId,
            position.coords.latitude,
            position.coords.longitude,
            'exact'
          );
          toast.success('Konum paylaşıldı');
        },
        (error) => {
          toast.error('Konum alınamadı: ' + error.message);
        }
      );
    } else {
      toast.error('Tarayıcınız konum paylaşımını desteklemiyor');
    }
  };

  const typingPartner = Array.from(typingUsers).find(id => id !== user?.id);

  if (matchesLoading) {
    return (
      <>
        <Navbar />
        <div className={styles.container}>
          <LoadingSkeleton type="messages" />
        </div>
      </>
    );
  }

  return (
    <div className={styles.messagesPage}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.messagesContainer}>
          {/* Sol Panel - Eşleşme Listesi */}
          <div className={styles.matchesPanel}>
            <div className={styles.panelHeader}>
              <h2>Mesajlar</h2>
              <span className={styles.onlineBadge}>
                {isConnected ? '🟢 Çevrimiçi' : '🔴 Bağlanıyor...'}
              </span>
            </div>

            <div className={styles.matchesList}>
              {matches?.length > 0 ? (
                matches.map(match => {
                  const partner = match.user_id_1 === user.id 
                    ? match.user_2 
                    : match.user_1;
                  
                  return (
                    <div
                      key={match.id}
                      className={`${styles.matchItem} ${
                        activeMatchId === String(match.id) ? styles.active : ''
                      }`}
                      onClick={() => navigate(`/messages/${match.id}`)}
                    >
                      <div className={styles.matchAvatar}>
                        <img 
                          src={partner.avatar_url || 'https://via.placeholder.com/50'} 
                          alt={partner.full_name} 
                        />
                        {partner.is_online && <span className={styles.onlineDot} />}
                      </div>
                      <div className={styles.matchInfo}>
                        <div className={styles.matchHeader}>
                          <h3>{partner.full_name}</h3>
                          <span className={styles.matchTime}>
                            {match.last_message_time && format(
                              new Date(match.last_message_time),
                              'HH:mm',
                              { locale: tr }
                            )}
                          </span>
                        </div>
                        <p className={styles.lastMessage}>
                          {match.last_message || 'Henüz mesaj yok'}
                        </p>
                      </div>
                      {match.unread_count > 0 && (
                        <span className={styles.unreadBadge}>{match.unread_count}</span>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className={styles.emptyMatches}>
                  <span>💬</span>
                  <p>Henüz eşleşme yok</p>
                  <button onClick={() => navigate('/dashboard')}>
                    Keşfetmeye Başla
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Sağ Panel - Sohbet */}
          <div className={styles.chatPanel}>
            {activeMatchId && currentMatch ? (
              <>
                {/* Sohbet Başlığı */}
                <div className={styles.chatHeader}>
                  <div className={styles.chatPartner}>
                    <img 
                      src={currentMatch.partner.avatar_url || 'https://via.placeholder.com/50'} 
                      alt={currentMatch.partner.full_name} 
                    />
                    <div>
                      <h3>{currentMatch.partner.full_name}</h3>
                      <p className={styles.partnerStatus}>
                        {typingPartner ? (
                          <span className={styles.typingIndicator}>Yazıyor...</span>
                        ) : currentMatch.partner.is_online ? (
                          'Çevrimiçi'
                        ) : (
                          'Çevrimdışı'
                        )}
                      </p>
                    </div>
                  </div>
                  <div className={styles.chatActions}>
                    <EmergencyButton compact />
                    <button 
                      className={styles.actionButton}
                      onClick={() => navigate(`/meetings/create/${activeMatchId}`)}
                      title="Randevu Planla"
                    >
                      📅
                    </button>
                    <button 
                      className={styles.actionButton}
                      onClick={handleShareLocation}
                      title="Konum Paylaş"
                    >
                      📍
                    </button>
                    <button 
                      className={styles.actionButton}
                      onClick={() => navigate(`/profile/${currentMatch.partner.id}`)}
                      title="Profili Görüntüle"
                    >
                      👤
                    </button>
                  </div>
                </div>

                {/* Mesaj Listesi */}
                <div className={styles.messagesList}>
                  {messagesLoading ? (
                    <LoadingSkeleton type="message-bubbles" />
                  ) : messages?.length > 0 ? (
                    <>
                      {messages.map((message, index) => {
                        const isOwn = message.sender_id === user.id;
                        const showDate = index === 0 || 
                          new Date(message.created_at).toDateString() !== 
                          new Date(messages[index - 1].created_at).toDateString();

                        return (
                          <React.Fragment key={message.id}>
                            {showDate && (
                              <div className={styles.dateDivider}>
                                <span>
                                  {format(new Date(message.created_at), 'd MMMM yyyy', { locale: tr })}
                                </span>
                              </div>
                            )}
                            
                            <motion.div
                              className={`${styles.message} ${isOwn ? styles.own : styles.other}`}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                            >
                              {message.content_type === 'location_share' ? (
                                <div className={styles.locationMessage}>
                                  <span>📍</span>
                                  <span>Konum paylaşıldı</span>
                                  <button className={styles.viewLocationButton}>
                                    Haritada Gör
                                  </button>
                                </div>
                              ) : (
                                <div className={styles.messageContent}>
                                  <p>{message.content}</p>
                                  <span className={styles.messageTime}>
                                    {format(new Date(message.created_at), 'HH:mm')}
                                    {isOwn && message.is_read && (
                                      <span className={styles.readReceipt}>✓✓</span>
                                    )}
                                  </span>
                                </div>
                              )}
                            </motion.div>
                          </React.Fragment>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </>
                  ) : (
                    <div className={styles.emptyChat}>
                      <span>💭</span>
                      <p>Henüz mesaj yok</p>
                      <p className={styles.emptySubtext}>
                        Sohbete başlamak için bir mesaj gönderin
                      </p>
                    </div>
                  )}
                </div>

                {/* Mesaj Gönderme */}
                <form onSubmit={handleSubmit(onSubmit)} className={styles.messageForm}>
                  <input
                    type="text"
                    placeholder="Mesajınızı yazın..."
                    {...register('message', { required: true })}
                    onKeyDown={handleTyping}
                    autoComplete="off"
                  />
                  <button 
                    type="submit" 
                    disabled={!messageContent?.trim() || sendMessageMutation.isLoading}
                  >
                    {sendMessageMutation.isLoading ? '⟳' : 'Gönder'}
                  </button>
                </form>

                {/* Güvenlik Uyarısı */}
                <div className={styles.safetyNote}>
                  <span>🛡️</span>
                  <p>
                    Kişisel bilgilerinizi paylaşırken dikkatli olun. 
                    İlk buluşmada halka açık yerleri tercih edin.
                  </p>
                </div>
              </>
            ) : (
              <div className={styles.noChat}>
                <span>👋</span>
                <h3>Sohbete Başla</h3>
                <p>Sohbet etmek için bir eşleşme seçin</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default MessagesPage;