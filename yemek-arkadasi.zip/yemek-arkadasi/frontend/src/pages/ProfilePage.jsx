import React, { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Navbar from '../components/common/Navbar';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import ReviewCard from '../components/profile/ReviewCard';
import VerificationProgress from '../components/profile/VerificationProgress';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import styles from './ProfilePage.module.css';

const ProfilePage = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { user: currentUser, updateUser } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);
  
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('profile'); // profile, photos, reviews, settings
  const [uploadingImage, setUploadingImage] = useState(false);

  const isOwnProfile = !userId || userId === String(currentUser?.id);
  const profileId = isOwnProfile ? currentUser?.id : userId;

  const { register, handleSubmit, formState: { errors, isDirty }, reset } = useForm({
    defaultValues: {
      full_name: currentUser?.full_name || '',
      bio: currentUser?.bio || '',
      age: currentUser?.age || '',
      gender: currentUser?.gender || '',
      phone: currentUser?.phone || '',
    }
  });

  // Profil verilerini getir
  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile', profileId],
    queryFn: async () => {
      const response = await api.get(`/users/${profileId}`);
      return response.data.data;
    },
    enabled: !!profileId,
  });

  // Değerlendirmeleri getir
  const { data: reviews } = useQuery({
    queryKey: ['reviews', profileId],
    queryFn: async () => {
      const response = await api.get(`/reviews/user/${profileId}`);
      return response.data.data;
    },
    enabled: !!profileId,
  });

  // Geçmiş buluşmaları getir
  const { data: pastMeetings } = useQuery({
    queryKey: ['past-meetings', profileId],
    queryFn: async () => {
      const response = await api.get(`/meetings/past/${profileId}`);
      return response.data.data;
    },
    enabled: !!profileId && isOwnProfile,
  });

  // Profil güncelleme mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.put('/users/profile', data);
      return response.data.data;
    },
    onSuccess: (data) => {
      updateUser(data);
      queryClient.invalidateQueries(['profile', profileId]);
      setIsEditing(false);
      toast.success('Profil başarıyla güncellendi');
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Güncelleme başarısız');
    },
  });

  // Fotoğraf yükleme
  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Dosya boyutu 5MB\'dan küçük olmalıdır');
      return;
    }

    const formData = new FormData();
    formData.append('avatar', file);

    setUploadingImage(true);

    try {
      const response = await api.post('/users/avatar', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      
      updateUser(response.data.data);
      queryClient.invalidateQueries(['profile', profileId]);
      toast.success('Profil fotoğrafı güncellendi');
    } catch (error) {
      toast.error('Fotoğraf yüklenemedi');
    } finally {
      setUploadingImage(false);
    }
  };

  const onSubmit = (data) => {
    updateProfileMutation.mutate(data);
  };

  const handleCancelEdit = () => {
    reset();
    setIsEditing(false);
  };

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className={styles.container}>
          <LoadingSkeleton type="profile" />
        </div>
      </>
    );
  }

  const displayUser = isOwnProfile ? { ...currentUser, ...profile } : profile;

  const verificationBadges = {
    bronze: { icon: '🥉', label: 'Bronz', color: '#CD7F32', next: 'silver' },
    silver: { icon: '🥈', label: 'Gümüş', color: '#C0C0C0', next: 'gold' },
    gold: { icon: '🥇', label: 'Altın', color: '#FFD700', next: 'platinum' },
    platinum: { icon: '💎', label: 'Platin', color: '#E5E4E2', next: null },
  };

  const currentBadge = verificationBadges[displayUser?.verification_level] || verificationBadges.bronze;

  return (
    <div className={styles.profilePage}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.container}>
          {/* Profil Header */}
          <div className={styles.profileHeader}>
            <div className={styles.coverPhoto}>
              <img 
                src={displayUser?.cover_url || 'https://via.placeholder.com/1200x300?text=Cover'} 
                alt="Cover" 
              />
              {isOwnProfile && (
                <button className={styles.editCoverButton}>
                  📷 Kapak Fotoğrafını Değiştir
                </button>
              )}
            </div>

            <div className={styles.profileInfo}>
              <div className={styles.avatarSection}>
                <div className={styles.avatar}>
                  <img 
                    src={displayUser?.avatar_url || 'https://via.placeholder.com/150?text=Avatar'} 
                    alt={displayUser?.full_name} 
                  />
                  {isOwnProfile && (
                    <>
                      <button 
                        className={styles.changeAvatarButton}
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadingImage}
                      >
                        {uploadingImage ? '⟳' : '📷'}
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        style={{ display: 'none' }}
                      />
                    </>
                  )}
                </div>
                
                <div className={styles.verificationBadge} style={{ backgroundColor: currentBadge.color }}>
                  <span>{currentBadge.icon}</span>
                  <span>{currentBadge.label} Üye</span>
                </div>
              </div>

              <div className={styles.userDetails}>
                <h1>{displayUser?.full_name}</h1>
                <p className={styles.userMeta}>
                  <span>📍 {displayUser?.location_city || 'Konum belirtilmemiş'}</span>
                  <span>🎂 {displayUser?.age} yaşında</span>
                  <span>🍴 {displayUser?.total_meals || 0} buluşma</span>
                </p>
                <p className={styles.bio}>{displayUser?.bio || 'Henüz biyografi eklenmemiş.'}</p>
              </div>

              {isOwnProfile ? (
                <button 
                  className={styles.editProfileButton}
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? 'İptal' : '✏️ Profili Düzenle'}
                </button>
              ) : (
                <button className={styles.messageButton}>
                  💬 Mesaj Gönder
                </button>
              )}
            </div>
          </div>

          {/* Tab Navigasyonu */}
          <div className={styles.tabs}>
            <button 
              className={`${styles.tab} ${activeTab === 'profile' ? styles.active : ''}`}
              onClick={() => setActiveTab('profile')}
            >
              Profil
            </button>
            {isOwnProfile && (
              <button 
                className={`${styles.tab} ${activeTab === 'verification' ? styles.active : ''}`}
                onClick={() => setActiveTab('verification')}
              >
                Doğrulama
              </button>
            )}
            <button 
              className={`${styles.tab} ${activeTab === 'reviews' ? styles.active : ''}`}
              onClick={() => setActiveTab('reviews')}
            >
              Değerlendirmeler
            </button>
            {isOwnProfile && (
              <button 
                className={`${styles.tab} ${activeTab === 'history' ? styles.active : ''}`}
                onClick={() => setActiveTab('history')}
              >
                Geçmiş Buluşmalar
              </button>
            )}
          </div>

          {/* Tab İçerikleri */}
          <div className={styles.tabContent}>
            <AnimatePresence mode="wait">
              {activeTab === 'profile' && (
                <motion.div
                  key="profile"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={styles.profileTab}
                >
                  {isEditing ? (
                    <form onSubmit={handleSubmit(onSubmit)} className={styles.editForm}>
                      <div className={styles.formGroup}>
                        <label>Ad Soyad</label>
                        <input
                          {...register('full_name', { 
                            required: 'Ad soyad gerekli',
                            minLength: { value: 3, message: 'En az 3 karakter' }
                          })}
                        />
                        {errors.full_name && (
                          <span className={styles.error}>{errors.full_name.message}</span>
                        )}
                      </div>

                      <div className={styles.formGroup}>
                        <label>Biyografi</label>
                        <textarea
                          {...register('bio', { maxLength: { value: 500, message: 'En fazla 500 karakter' } })}
                          rows={4}
                          placeholder="Kendinizden bahsedin..."
                        />
                      </div>

                      <div className={styles.formRow}>
                        <div className={styles.formGroup}>
                          <label>Yaş</label>
                          <input
                            type="number"
                            {...register('age', { 
                              required: 'Yaş gerekli',
                              min: { value: 18, message: 'En az 18 yaş' },
                              max: { value: 100, message: 'En fazla 100 yaş' }
                            })}
                          />
                        </div>

                        <div className={styles.formGroup}>
                          <label>Cinsiyet</label>
                          <select {...register('gender')}>
                            <option value="erkek">Erkek</option>
                            <option value="kadın">Kadın</option>
                            <option value="diğer">Diğer</option>
                            <option value="belirtmek_istemiyorum">Belirtmek İstemiyorum</option>
                          </select>
                        </div>
                      </div>

                      <div className={styles.formGroup}>
                        <label>Telefon</label>
                        <input
                          {...register('phone', { 
                            pattern: { 
                              value: /^[0-9]{10,11}$/, 
                              message: 'Geçerli bir telefon numarası giriniz' 
                            }
                          })}
                        />
                      </div>

                      <div className={styles.formActions}>
                        <button 
                          type="button" 
                          className={styles.cancelButton}
                          onClick={handleCancelEdit}
                        >
                          İptal
                        </button>
                        <button 
                          type="submit" 
                          className={styles.saveButton}
                          disabled={!isDirty || updateProfileMutation.isLoading}
                        >
                          {updateProfileMutation.isLoading ? 'Kaydediliyor...' : 'Kaydet'}
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className={styles.profileDetails}>
                      <div className={styles.infoSection}>
                        <h3>Yemek Tercihleri</h3>
                        <div className={styles.preferenceTags}>
                          {displayUser?.food_preferences?.mutfaklar?.map(cuisine => (
                            <span key={cuisine} className={styles.tag}>{cuisine}</span>
                          )) || <span className={styles.empty}>Henüz belirtilmemiş</span>}
                        </div>
                      </div>

                      <div className={styles.infoSection}>
                        <h3>Bütçe Aralığı</h3>
                        <p>{displayUser?.budget_range || 'Belirtilmemiş'}</p>
                      </div>

                      <div className={styles.infoSection}>
                        <h3>Sohbet Tarzı</h3>
                        <p>{displayUser?.conversation_style || 'Belirtilmemiş'}</p>
                      </div>

                      <div className={styles.infoSection}>
                        <h3>İstatistikler</h3>
                        <div className={styles.statsGrid}>
                          <div className={styles.statCard}>
                            <span className={styles.statValue}>{displayUser?.total_meals || 0}</span>
                            <span className={styles.statLabel}>Toplam Buluşma</span>
                          </div>
                          <div className={styles.statCard}>
                            <span className={styles.statValue}>{displayUser?.rating_average?.toFixed(1) || '0.0'}</span>
                            <span className={styles.statLabel}>Ortalama Puan</span>
                          </div>
                          <div className={styles.statCard}>
                            <span className={styles.statValue}>{displayUser?.total_reviews || 0}</span>
                            <span className={styles.statLabel}>Değerlendirme</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'verification' && isOwnProfile && (
                <motion.div
                  key="verification"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <VerificationProgress 
                    currentLevel={displayUser?.verification_level}
                    onLevelUp={() => {
                      queryClient.invalidateQueries(['profile', profileId]);
                    }}
                  />
                </motion.div>
              )}

              {activeTab === 'reviews' && (
                <motion.div
                  key="reviews"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={styles.reviewsTab}
                >
                  {reviews?.length > 0 ? (
                    <div className={styles.reviewsList}>
                      {reviews.map(review => (
                        <ReviewCard key={review.id} review={review} />
                      ))}
                    </div>
                  ) : (
                    <div className={styles.emptyState}>
                      <span>📝</span>
                      <p>Henüz değerlendirme yok</p>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'history' && isOwnProfile && (
                <motion.div
                  key="history"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={styles.historyTab}
                >
                  {pastMeetings?.length > 0 ? (
                    <div className={styles.meetingsList}>
                      {pastMeetings.map(meeting => (
                        <div key={meeting.id} className={styles.meetingCard}>
                          <div className={styles.meetingHeader}>
                            <img 
                              src={meeting.partner.avatar_url || 'https://via.placeholder.com/50'} 
                              alt={meeting.partner.full_name} 
                            />
                            <div>
                              <h4>{meeting.partner.full_name}</h4>
                              <p>{new Date(meeting.scheduled_at).toLocaleDateString('tr-TR')}</p>
                            </div>
                          </div>
                          <div className={styles.meetingDetails}>
                            <span>📍 {meeting.restaurant?.name || 'Restoran belirtilmemiş'}</span>
                            <span className={`${styles.status} ${styles[meeting.status]}`}>
                              {meeting.status === 'completed' ? 'Tamamlandı' : 'İptal Edildi'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className={styles.emptyState}>
                      <span>🍽️</span>
                      <p>Henüz geçmiş buluşma yok</p>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProfilePage;