import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Navbar from '../components/common/Navbar';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import RestaurantCard from '../components/restaurants/RestaurantCard';
import api from '../utils/api';
import styles from './RestaurantsPage.module.css';

// Leaflet marker ikonları
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const RestaurantsPage = () => {
  const [viewMode, setViewMode] = useState('list'); // list, map
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [filters, setFilters] = useState({
    cuisine_type: '',
    price_range: '',
    distance: 10,
    rating: 0,
  });
  const [userLocation, setUserLocation] = useState(null);

  const { register, watch } = useForm({
    defaultValues: filters,
  });

  // Kullanıcı konumunu al
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Konum alınamadı:', error);
          // Varsayılan konum (İstanbul)
          setUserLocation({ lat: 41.0082, lng: 28.9784 });
        }
      );
    }
  }, []);

  // Restoranları getir
  const { data: restaurants, isLoading } = useQuery({
    queryKey: ['restaurants', filters, userLocation],
    queryFn: async () => {
      const params = {
        ...filters,
        lat: userLocation?.lat,
        lng: userLocation?.lng,
      };
      const response = await api.get('/restaurants', { params });
      return response.data.data;
    },
    enabled: !!userLocation,
  });

  const watchedFilters = watch();
  
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setFilters(watchedFilters);
    }, 500);
    return () => clearTimeout(timeoutId);
  }, [watchedFilters]);

  const cuisineTypes = [
    'Türk Mutfağı',
    'İtalyan Mutfağı',
    'Japon Mutfağı',
    'Çin Mutfağı',
    'Meksika Mutfağı',
    'Hint Mutfağı',
    'Vejetaryen',
    'Vegan',
    'Deniz Ürünleri',
    'Kebap & Izgara',
    'Ev Yemekleri',
    'Fast Food',
  ];

  const priceRanges = [
    { value: 'ekonomik', label: 'Ekonomik (₺)' },
    { value: 'orta', label: 'Orta (₺₺)' },
    { value: 'pahalı', label: 'Pahalı (₺₺₺)' },
  ];

  const ratingOptions = [
    { value: 0, label: 'Tümü' },
    { value: 3, label: '3+ Yıldız' },
    { value: 4, label: '4+ Yıldız' },
    { value: 4.5, label: '4.5+ Yıldız' },
  ];

  return (
    <div className={styles.restaurantsPage}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.container}>
          {/* Başlık */}
          <div className={styles.header}>
            <h1>Restoranlar</h1>
            <div className={styles.viewToggle}>
              <button 
                className={`${styles.viewButton} ${viewMode === 'list' ? styles.active : ''}`}
                onClick={() => setViewMode('list')}
              >
                📋 Liste
              </button>
              <button 
                className={`${styles.viewButton} ${viewMode === 'map' ? styles.active : ''}`}
                onClick={() => setViewMode('map')}
              >
                🗺️ Harita
              </button>
            </div>
          </div>

          <div className={styles.content}>
            {/* Filtre Paneli */}
            <aside className={styles.filterPanel}>
              <h3>Filtreler</h3>
              
              <div className={styles.filterGroup}>
                <label>Mutfak Türü</label>
                <select {...register('cuisine_type')}>
                  <option value="">Tüm Mutfaklar</option>
                  {cuisineTypes.map(cuisine => (
                    <option key={cuisine} value={cuisine}>{cuisine}</option>
                  ))}
                </select>
              </div>

              <div className={styles.filterGroup}>
                <label>Fiyat Aralığı</label>
                <div className={styles.priceOptions}>
                  {priceRanges.map(range => (
                    <label key={range.value} className={styles.radioLabel}>
                      <input 
                        type="radio" 
                        value={range.value} 
                        {...register('price_range')} 
                      />
                      <span>{range.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className={styles.filterGroup}>
                <label>Mesafe (km)</label>
                <input 
                  type="range" 
                  min="1" 
                  max="50" 
                  {...register('distance')} 
                />
                <span className={styles.rangeValue}>{watchedFilters.distance} km</span>
              </div>

              <div className={styles.filterGroup}>
                <label>Minimum Puan</label>
                <select {...register('rating')}>
                  {ratingOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              <button 
                className={styles.resetButton}
                onClick={() => {
                  setFilters({
                    cuisine_type: '',
                    price_range: '',
                    distance: 10,
                    rating: 0,
                  });
                }}
              >
                Filtreleri Sıfırla
              </button>
            </aside>

            {/* Ana İçerik */}
            <section className={styles.mainContent}>
              {viewMode === 'list' ? (
                <>
                  {/* Sıralama */}
                  <div className={styles.sortBar}>
                    <span>{restaurants?.length || 0} restoran bulundu</span>
                    <select className={styles.sortSelect}>
                      <option value="distance">En Yakın</option>
                      <option value="rating">En Yüksek Puan</option>
                      <option value="price_asc">Fiyat (Düşükten Yükseğe)</option>
                      <option value="price_desc">Fiyat (Yüksekten Düşüğe)</option>
                    </select>
                  </div>

                  {/* Restoran Listesi */}
                  <div className={styles.restaurantList}>
                    {isLoading ? (
                      <LoadingSkeleton type="restaurant" count={6} />
                    ) : restaurants?.length > 0 ? (
                      restaurants.map((restaurant, index) => (
                        <motion.div
                          key={restaurant.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <RestaurantCard 
                            restaurant={restaurant}
                            onSelect={() => setSelectedRestaurant(restaurant)}
                          />
                        </motion.div>
                      ))
                    ) : (
                      <div className={styles.emptyState}>
                        <span>🍽️</span>
                        <h3>Restoran Bulunamadı</h3>
                        <p>Filtrelerinizi değiştirerek tekrar deneyin.</p>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className={styles.mapContainer}>
                  {userLocation && (
                    <MapContainer
                      center={[userLocation.lat, userLocation.lng]}
                      zoom={13}
                      className={styles.map}
                    >
                      <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      />
                      
                      {/* Kullanıcı Konumu */}
                      <Marker position={[userLocation.lat, userLocation.lng]}>
                        <Popup>
                          <strong>Sizin Konumunuz</strong>
                        </Popup>
                      </Marker>

                      {/* Restoran Marker'ları */}
                      {restaurants?.map(restaurant => (
                        <Marker
                          key={restaurant.id}
                          position={[restaurant.latitude, restaurant.longitude]}
                        >
                          <Popup>
                            <div className={styles.mapPopup}>
                              <img 
                                src={restaurant.image_url || 'https://via.placeholder.com/100'} 
                                alt={restaurant.name} 
                              />
                              <div>
                                <h4>{restaurant.name}</h4>
                                <p>{restaurant.cuisine_type} • {restaurant.price_range}</p>
                                <p>⭐ {restaurant.rating?.toFixed(1)}</p>
                                <button 
                                  className={styles.viewDetailsButton}
                                  onClick={() => setSelectedRestaurant(restaurant)}
                                >
                                  Detayları Gör
                                </button>
                              </div>
                            </div>
                          </Popup>
                        </Marker>
                      ))}
                    </MapContainer>
                  )}
                </div>
              )}
            </section>
          </div>
        </div>
      </main>

      {/* Restoran Detay Modal */}
      <AnimatePresence>
        {selectedRestaurant && (
          <RestaurantDetailModal
            restaurant={selectedRestaurant}
            onClose={() => setSelectedRestaurant(null)}
            userLocation={userLocation}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default RestaurantsPage;