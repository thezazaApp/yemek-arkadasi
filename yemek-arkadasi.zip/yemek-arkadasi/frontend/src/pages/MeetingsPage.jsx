import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { format, addDays, isAfter, isBefore } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';
import Navbar from '../components/common/Navbar';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import SafetyChecklist from '../components/meetings/SafetyChecklist';
import ReviewForm from '../components/meetings/ReviewForm';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import styles from './MeetingsPage.module.css';

const MeetingsPage = () => {
  const { matchId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [activeTab, setActiveTab] = useState('upcoming'); // upcoming, past, cancelled

  const { register, handleSubmit, formState: { errors }, reset, watch } = useForm({
    defaultValues: {
      restaurant_id: '',
      scheduled_at: format(addDays(new Date(), 1), "yyyy-MM-dd'T'HH:mm"),
      duration_minutes: 120,
    }
  });

  // Randevuları getir
  const { data: meetings, isLoading } = useQuery({
    queryKey: ['meetings', activeTab],
    queryFn: async () => {
      const response = await api.get('/meetings', { 
        params: { type: activeTab } 
      });
      return response.data.data;
    },
  });

  // Restoranları getir
  const { data: restaurants } = useQuery({
    queryKey: ['restaurants', 'nearby'],
    queryFn: async () => {
      const response = await api.get('/restaurants/nearby');
      return response.data.data;
    },
    enabled: showCreateModal,
  });

  // Randevu oluşturma mutation
  const createMeetingMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.post('/meetings', {
        ...data,
        match_id: matchId || data.match_id,
      });
      return response.data.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['meetings']);
      setShowCreateModal(false);
      reset();
      toast.success('Randevu başarıyla oluşturuldu');
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Randevu oluşturulamadı');
    },
  });

  // Randevu iptal mutation
  const cancelMeetingMutation = useMutation({
    mutationFn: async ({ meetingId, reason }) => {
      const response = await api.post(`/meetings/${meetingId}/cancel`, { reason });
      return response.data.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['meetings']);
      toast.success('Randevu iptal edildi');
    },
  });

  // Randevu tamamlama mutation
  const completeMeetingMutation = useMutation({
    mutationFn: async (meetingId) => {
      const response = await api.post(`/meetings/${meetingId}/complete`);
      return response.data.data;
    },
    onSuccess: (data, meetingId) => {
      queryClient.invalidateQueries(['meetings']);
      setSelectedMeeting(meetingId);
      setShowReviewModal(true);
    },
  });

  const onSubmit = (data) => {
    createMeetingMutation.mutate(data);
  };

  const handleCancelMeeting = (meetingId) => {
    const reason = prompt('İptal sebebini yazabilir misiniz? (Opsiyonel)');
    cancelMeetingMutation.mutate({ meetingId, reason });
  };

  const handleCompleteMeeting = (meetingId) => {
    if (confirm('Randevuyu tamamlandı olarak işaretlemek istediğinize emin misiniz?')) {
      completeMeetingMutation.mutate(meetingId);
    }
  };

  const getMeetingStatus = (meeting) => {
    const now = new Date();
    const meetingTime = new Date(meeting.scheduled_at);

    if (meeting.status === 'cancelled') return 'cancelled';
    if (meeting.status === 'completed') return 'completed';
    if (isBefore(meetingTime, now) && isAfter(addDays(meetingTime, 0), now)) return 'active';
    if (isAfter(meetingTime, now)) return 'upcoming';
    return 'past';
  };

  const statusConfig = {
    upcoming: { label: 'Yaklaşan', color: '#4ECDC4', icon: '📅' },
    active: { label: 'Aktif', color: '#27AE60', icon: '🟢' },
    completed: { label: 'Tamamlandı', color: '#95A5A6', icon: '✅' },
    cancelled: { label: 'İptal', color: '#E74C3C', icon: '❌' },
    past: { label: 'Geçmiş', color: '#95A5A6', icon: '📅' },
  };

  return (
    <div className={styles.meetingsPage}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.container}>
          {/* Başlık ve Aksiyonlar */}
          <div className={styles.header}>
            <h1>Randevularım</h1>
            <button 
              className={styles.createButton}
              onClick={() => setShowCreateModal(true)}
            >
              + Yeni Randevu Oluştur
            </button>
          </div>

          {/* Tab Navigasyonu */}
          <div className={styles.tabs}>
            <button 
              className={`${styles.tab} ${activeTab === 'upcoming' ? styles.active : ''}`}
              onClick={() => setActiveTab('upcoming')}
            >
              Yaklaşan Randevular
            </button>
            <button 
              className={`${styles.tab} ${activeTab === 'past' ? styles.active : ''}`}
              onClick={() => setActiveTab('past')}
            >
              Geçmiş Randevular
            </button>
            <button 
              className={`${styles.tab} ${activeTab === 'cancelled' ? styles.active : ''}`}
              onClick={() => setActiveTab('cancelled')}
            >
              İptal Edilenler
            </button>
          </div>

          {/* Randevu Listesi */}
          <div className={styles.meetingsList}>
            {isLoading ? (
              <LoadingSkeleton type="meetings" count={3} />
            ) : meetings?.length > 0 ? (
              meetings.map(meeting => {
                const partner = meeting.partner;
                const status = getMeetingStatus(meeting);
                const config = statusConfig[status];

                return (
                  <motion.div
                    key={meeting.id}
                    className={styles.meetingCard}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <div className={styles.meetingHeader}>
                      <div className={styles.partnerInfo}>
                        <img 
                          src={partner.avatar_url || 'https://via.placeholder.com/60'} 
                          alt={partner.full_name} 
                        />
                        <div>
                          <h3>{partner.full_name}</h3>
                          <div className={styles.meetingMeta}>
                            <span className={styles.restaurant}>
                              🍽️ {meeting.restaurant?.name || 'Restoran belirtilmemiş'}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div 
                        className={styles.statusBadge}
                        style={{ backgroundColor: config.color }}
                      >
                        <span>{config.icon}</span>
                        <span>{config.label}</span>
                      </div>
                    </div>

                    <div className={styles.meetingDetails}>
                      <div className={styles.detailItem}>
                        <span>📅</span>
                        <span>
                          {format(new Date(meeting.scheduled_at), 'dd MMMM yyyy, EEEE', { locale: tr })}
                        </span>
                      </div>
                      <div className={styles.detailItem}>
                        <span>⏰</span>
                        <span>
                          {format(new Date(meeting.scheduled_at), 'HH:mm')} 
                          ({meeting.duration_minutes} dakika)
                        </span>
                      </div>
                      <div className={styles.detailItem}>
                        <span>📍</span>
                        <span>{meeting.restaurant?.address || 'Adres paylaşılmadı'}</span>
                      </div>
                    </div>

                    {/* Güvenlik Kontrol Listesi */}
                    {status === 'upcoming' && !meeting.safety_checklist_completed && (
                      <div className={styles.safetyWarning}>
                        <SafetyChecklist 
                          meetingId={meeting.id}
                          onComplete={() => {
                            queryClient.invalidateQueries(['meetings']);
                          }}
                        />
                      </div>
                    )}

                    <div className={styles.meetingActions}>
                      {status === 'upcoming' && (
                        <>
                          <button 
                            className={styles.actionButton}
                            onClick={() => navigate(`/messages/${meeting.match_id}`)}
                          >
                            💬 Mesaj Gönder
                          </button>
                          <button 
                            className={`${styles.actionButton} ${styles.danger}`}
                            onClick={() => handleCancelMeeting(meeting.id)}
                          >
                            İptal Et
                          </button>
                        </>
                      )}

                      {status === 'active' && (
                        <>
                          <EmergencyButton meetingId={meeting.id} />
                          <button 
                            className={`${styles.actionButton} ${styles.success}`}
                            onClick={() => handleCompleteMeeting(meeting.id)}
                          >
                            Tamamlandı
                          </button>
                        </>
                      )}

                      {status === 'completed' && !meeting.reviewed && (
                        <button 
                          className={styles.actionButton}
                          onClick={() => {
                            setSelectedMeeting(meeting.id);
                            setShowReviewModal(true);
                          }}
                        >
                          ⭐ Değerlendir
                        </button>
                      )}

                      <button 
                        className={styles.actionButton}
                        onClick={() => navigate(`/restaurants/${meeting.restaurant_id}`)}
                      >
                        🍽️ Restoran Detayları
                      </button>
                    </div>
                  </motion.div>
                );
              })
            ) : (
              <div className={styles.emptyState}>
                <span>📅</span>
                <h3>Randevu Bulunamadı</h3>
                <p>
                  {activeTab === 'upcoming' 
                    ? 'Henüz yaklaşan bir randevunuz yok.'
                    : activeTab === 'past'
                    ? 'Geçmiş randevunuz bulunmuyor.'
                    : 'İptal edilmiş randevunuz yok.'}
                </p>
                {activeTab === 'upcoming' && (
                  <button onClick={() => setShowCreateModal(true)}>
                    Randevu Oluştur
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Randevu Oluşturma Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            className={styles.modalOverlay}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowCreateModal(false)}
          >
            <motion.div
              className={styles.modal}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
            >
              <div className={styles.modalHeader}>
                <h2>Yeni Randevu Oluştur</h2>
                <button onClick={() => setShowCreateModal(false)}>✕</button>
              </div>

              <form onSubmit={handleSubmit(onSubmit)} className={styles.modalForm}>
                {!matchId && (
                  <div className={styles.formGroup}>
                    <label>Eşleşme Seçin</label>
                    <select {...register('match_id', { required: 'Eşleşme seçin' })}>
                      <option value="">Seçiniz</option>
                      {/* Eşleşmeler burada listelenecek */}
                    </select>
                    {errors.match_id && (
                      <span className={styles.error}>{errors.match_id.message}</span>
                    )}
                  </div>
                )}

                <div className={styles.formGroup}>
                  <label>Restoran Seçin</label>
                  <select {...register('restaurant_id')}>
                    <option value="">Restoran seçin (Opsiyonel)</option>
                    {restaurants?.map(restaurant => (
                      <option key={restaurant.id} value={restaurant.id}>
                        {restaurant.name} - {restaurant.cuisine_type} ({restaurant.price_range})
                      </option>
                    ))}
                  </select>
                </div>

                <div className={styles.formRow}>
                  <div className={styles.formGroup}>
                    <label>Tarih ve Saat</label>
                    <input
                      type="datetime-local"
                      {...register('scheduled_at', { 
                        required: 'Tarih ve saat seçin',
                        validate: value => {
                          const date = new Date(value);
                          const now = new Date();
                          const maxDate = addDays(now, 90);
                          
                          if (isBefore(date, now)) {
                            return 'Geçmiş bir tarih seçemezsiniz';
                          }
                          if (isAfter(date, maxDate)) {
                            return 'En fazla 3 ay sonrası için randevu oluşturabilirsiniz';
                          }
                          return true;
                        }
                      })}
                    />
                    {errors.scheduled_at && (
                      <span className={styles.error}>{errors.scheduled_at.message}</span>
                    )}
                  </div>

                  <div className={styles.formGroup}>
                    <label>Süre (dakika)</label>
                    <select {...register('duration_minutes')}>
                      <option value={60}>1 Saat</option>
                      <option value={90}>1.5 Saat</option>
                      <option value={120}>2 Saat</option>
                      <option value={180}>3 Saat</option>
                    </select>
                  </div>
                </div>

                <div className={styles.safetyReminder}>
                  <span>🛡️</span>
                  <div>
                    <h4>Güvenlik Hatırlatması</h4>
                    <ul>
                      <li>İlk buluşmada halka açık, kalabalık mekanları tercih edin</li>
                      <li>Randevu öncesi güvenlik kontrol listesini tamamlayın</li>
                      <li>Acil durumda panik butonunu kullanın</li>
                    </ul>
                  </div>
                </div>

                <div className={styles.modalActions}>
                  <button 
                    type="button" 
                    className={styles.cancelButton}
                    onClick={() => setShowCreateModal(false)}
                  >
                    İptal
                  </button>
                  <button 
                    type="submit" 
                    className={styles.submitButton}
                    disabled={createMeetingMutation.isLoading}
                  >
                    {createMeetingMutation.isLoading ? 'Oluşturuluyor...' : 'Randevu Oluştur'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Değerlendirme Modal */}
      <AnimatePresence>
        {showReviewModal && (
          <ReviewForm
            meetingId={selectedMeeting}
            onClose={() => {
              setShowReviewModal(false);
              setSelectedMeeting(null);
            }}
            onSuccess={() => {
              queryClient.invalidateQueries(['meetings']);
              setShowReviewModal(false);
              setSelectedMeeting(null);
              toast.success('Değerlendirmeniz için teşekkürler!');
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default MeetingsPage;