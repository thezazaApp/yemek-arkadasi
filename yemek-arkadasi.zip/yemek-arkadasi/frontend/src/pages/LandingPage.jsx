import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import styles from './LandingPage.module.css';

const LandingPage = () => {
  const controls = useAnimation();
  const [ref, inView] = useInView({ triggerOnce: true });

  useEffect(() => {
    if (inView) {
      controls.start('visible');
    }
  }, [controls, inView]);

  const fadeInUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const stats = [
    { value: '50K+', label: 'Aktif Kullanıcı' },
    { value: '25K+', label: 'Başarılı Buluşma' },
    { value: '4.8', label: 'Kullanıcı Puanı' },
    { value: '100%', label: 'Güvenli Ortam' },
  ];

  const features = [
    {
      icon: '🛡️',
      title: 'Kademeli Doğrulama',
      description: 'Bronz\'dan Platin\'e 4 seviye güvenlik doğrulaması'
    },
    {
      icon: '📍',
      title: 'Akıllı Konum Paylaşımı',
      description: 'Sohbet ilerledikçe kademeli konum paylaşımı'
    },
    {
      icon: '⭐',
      title: 'Puanlama Sistemi',
      description: 'Her buluşma sonrası karşılıklı değerlendirme'
    },
    {
      icon: '🚨',
      title: '7/24 Acil Destek',
      description: 'Her ekranda gizli panik butonu'
    },
  ];

  const steps = [
    {
      step: 1,
      title: 'Profilini Oluştur',
      description: 'Yemek tercihlerini ve bütçeni belirle'
    },
    {
      step: 2,
      title: 'Doğrulama Yap',
      description: 'Güvenliğin için kimliğini doğrula'
    },
    {
      step: 3,
      title: 'Eşleş',
      description: 'Ortak zevklere sahip kişilerle tanış'
    },
    {
      step: 4,
      title: 'Buluş ve Değerlendir',
      description: 'Güvenle yemek ye, puanını ver'
    },
  ];

  return (
    <div className={styles.landingPage}>
      {/* Hero Section */}
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <motion.div
            className={styles.heroText}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className={styles.heroTitle}>
              Yalnız Yemek <span>Yemeyin</span>
            </h1>
            <p className={styles.heroSubtitle}>
              Güvenli ortamda yeni insanlarla tanışın, keyifli yemekler paylaşın.
              Türkiye'nin en güvenilir sosyal yemek platformu.
            </p>
            <div className={styles.heroButtons}>
              <Link to="/register" className={styles.primaryButton}>
                Hemen Başla <span>→</span>
              </Link>
              <Link to="/login" className={styles.secondaryButton}>
                Giriş Yap
              </Link>
            </div>
            <div className={styles.heroStats}>
              {stats.map((stat, index) => (
                <div key={index} className={styles.statItem}>
                  <span className={styles.statValue}>{stat.value}</span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            className={styles.heroImage}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className={styles.heroImageWrapper}>
              <div className={styles.floatingCard1}>
                <span>🍕 İtalyan</span>
              </div>
              <div className={styles.floatingCard2}>
                <span>🍣 Japon</span>
              </div>
              <div className={styles.floatingCard3}>
                <span>🥘 Türk</span>
              </div>
              <div className={styles.mainImage}>
                <span>🍽️</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className={styles.features} ref={ref}>
        <motion.div
          className={styles.sectionHeader}
          variants={fadeInUp}
          initial="hidden"
          animate={controls}
        >
          <h2>Neden Yemek Arkadaşı?</h2>
          <p>Güvenliğiniz bizim önceliğimiz</p>
        </motion.div>

        <div className={styles.featuresGrid}>
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className={styles.featureCard}
              variants={fadeInUp}
              initial="hidden"
              animate={controls}
              transition={{ delay: index * 0.1 }}
            >
              <span className={styles.featureIcon}>{feature.icon}</span>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className={styles.howItWorks}>
        <div className={styles.sectionHeader}>
          <h2>Nasıl Çalışır?</h2>
          <p>4 adımda yemek arkadaşınla buluş</p>
        </div>

        <div className={styles.stepsContainer}>
          {steps.map((step, index) => (
            <motion.div
              key={index}
              className={styles.stepCard}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.15 }}
              viewport={{ once: true }}
            >
              <div className={styles.stepNumber}>{step.step}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
              {index < steps.length - 1 && (
                <div className={styles.stepConnector}>→</div>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      {/* Safety Section */}
      <section className={styles.safety}>
        <div className={styles.safetyContent}>
          <motion.div
            className={styles.safetyText}
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2>Güvenliğiniz İçin Çalışıyoruz</h2>
            <ul className={styles.safetyList}>
              <li>
                <span>✅</span> Kimlik doğrulama sistemi
              </li>
              <li>
                <span>✅</span> Kullanıcı puanlama ve değerlendirme
              </li>
              <li>
                <span>✅</span> Kademeli konum paylaşımı
              </li>
              <li>
                <span>✅</span> 7/24 acil durum desteği
              </li>
              <li>
                <span>✅</span> Yapay zeka destekli içerik moderasyonu
              </li>
            </ul>
          </motion.div>
          <motion.div
            className={styles.safetyImage}
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className={styles.shieldIcon}>🛡️</div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Yemek Arkadaşını Bulmaya Hazır mısın?</h2>
          <p>Hemen ücretsiz üye ol, güvenli yemek buluşmalarına başla!</p>
          <Link to="/register" className={styles.ctaButton}>
            Ücretsiz Başla <span>🚀</span>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <div className={styles.footerContent}>
          <div className={styles.footerSection}>
            <h4>Yemek Arkadaşı</h4>
            <p>Güvenli sosyal yemek buluşma platformu</p>
          </div>
          <div className={styles.footerSection}>
            <h4>Hızlı Linkler</h4>
            <Link to="/about">Hakkımızda</Link>
            <Link to="/safety">Güvenlik</Link>
            <Link to="/blog">Blog</Link>
          </div>
          <div className={styles.footerSection}>
            <h4>Yasal</h4>
            <Link to="/privacy">Gizlilik Politikası</Link>
            <Link to="/terms">Kullanım Koşulları</Link>
            <Link to="/contact">İletişim</Link>
          </div>
        </div>
        <div className={styles.footerBottom}>
          <p>&copy; 2024 Yemek Arkadaşı. Tüm hakları saklıdır.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;