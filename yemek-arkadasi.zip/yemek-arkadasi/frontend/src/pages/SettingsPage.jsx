import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import Navbar from '../components/common/Navbar';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import styles from './SettingsPage.module.css';

const SettingsPage = () => {
  const { user, updateUser } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('account');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Hesap Ayarları Form
  const accountForm = useForm({
    defaultValues: {
      email: user?.email || '',
      phone: user?.phone || '',
    },
  });

  // Bildirim Ayarları Form
  const notificationForm = useForm({
    defaultValues: {
      email_notifications: true,
      push_notifications: true,
      match_notifications: true,
      message_notifications: true,
      meeting_reminders: true,
      review_reminders: true,
      marketing_emails: false,
    },
  });

  // Gizlilik Ayarları Form
  const privacyForm = useForm({
    defaultValues: {
      profile_visibility: 'public',
      show_online_status: true,
      show_distance: true,
      show_age: true,
      allow_messages_from: 'matches_only',
      block_screenshots: false,
    },
  });

  // Güvenlik Ayarları Form
  const securityForm = useForm({
    defaultValues: {
      two_factor_enabled: false,
      login_alerts: true,
      trusted_devices_only: false,
    },
  });

  // Şifre Değiştirme Form
  const passwordForm = useForm({
    defaultValues: {
      current_password: '',
      new_password: '',
      confirm_password: '',
    },
  });

  // Hesap güncelleme mutation
  const updateAccountMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.put('/users/settings/account', data);
      return response.data;
    },
    onSuccess: () => {
      toast.success('Hesap ayarları güncellendi');
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Güncelleme başarısız');
    },
  });

  // Bildirim ayarları mutation
  const updateNotificationsMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.put('/users/settings/notifications', data);
      return response.data;
    },
    onSuccess: () => {
      toast.success('Bildirim ayarları güncellendi');
    },
  });

  // Gizlilik ayarları mutation
  const updatePrivacyMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.put('/users/settings/privacy', data);
      return response.data;
    },
    onSuccess: () => {
      toast.success('Gizlilik ayarları güncellendi');
    },
  });

  // Şifre değiştirme mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.put('/users/settings/password', data);
      return response.data;
    },
    onSuccess: () => {
      toast.success('Şifreniz başarıyla değiştirildi');
      passwordForm.reset();
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Şifre değiştirilemedi');
    },
  });

  // Hesap silme mutation
  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await api.delete('/users/account');
      return response.data;
    },
    onSuccess: () => {
      toast.success('Hesabınız silindi');
      localStorage.removeItem('token');
      window.location.href = '/';
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Hesap silinemedi');
    },
  });

  const onAccountSubmit = (data) => {
    updateAccountMutation.mutate(data);
  };

  const onNotificationsSubmit = (data) => {
    updateNotificationsMutation.mutate(data);
  };

  const onPrivacySubmit = (data) => {
    updatePrivacyMutation.mutate(data);
  };

  const onPasswordSubmit = (data) => {
    if (data.new_password !== data.confirm_password) {
      toast.error('Yeni şifreler eşleşmiyor');
      return;
    }
    changePasswordMutation.mutate({
      current_password: data.current_password,
      new_password: data.new_password,
    });
  };

  const handleDeleteAccount = () => {
    deleteAccountMutation.mutate();
    setShowDeleteConfirm(false);
  };

  const tabs = [
    { id: 'account', label: 'Hesap', icon: '👤' },
    { id: 'notifications', label: 'Bildirimler', icon: '🔔' },
    { id: 'privacy', label: 'Gizlilik', icon: '🔒' },
    { id: 'security', label: 'Güvenlik', icon: '🛡️' },
    { id: 'blocked', label: 'Engellenenler', icon: '🚫' },
    { id: 'data', label: 'Verilerim', icon: '📊' },
  ];

  return (
    <div className={styles.settingsPage}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.container}>
          <h1 className={styles.pageTitle}>Ayarlar</h1>

          <div className={styles.settingsLayout}>
            {/* Sol Navigasyon */}
            <aside className={styles.sidebar}>
              <nav className={styles.tabsNav}>
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    className={`${styles.tabButton} ${activeTab === tab.id ? styles.active : ''}`}
                    onClick={() => setActiveTab(tab.id)}
                  >
                    <span className={styles.tabIcon}>{tab.icon}</span>
                    <span className={styles.tabLabel}>{tab.label}</span>
                  </button>
                ))}
              </nav>

              <div className={styles.sidebarFooter}>
                <button 
                  className={styles.deleteAccountButton}
                  onClick={() => setShowDeleteConfirm(true)}
                >
                  🗑️ Hesabı Sil
                </button>
              </div>
            </aside>

            {/* Sağ İçerik */}
            <section className={styles.content}>
              {/* Hesap Ayarları */}
              {activeTab === 'account' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={styles.settingsSection}
                >
                  <h2>Hesap Ayarları</h2>
                  
                  <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className={styles.form}>
                    <div className={styles.formGroup}>
                      <label>E-posta Adresi</label>
                      <input
                        type="email"
                        {...accountForm.register('email', {
                          required: 'E-posta gerekli',
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: 'Geçerli bir e-posta girin',
                          },
                        })}
                      />
                      {accountForm.formState.errors.email && (
                        <span className={styles.error}>
                          {accountForm.formState.errors.email.message}
                        </span>
                      )}
                    </div>

                    <div className={styles.formGroup}>
                      <label>Telefon Numarası</label>
                      <input
                        type="tel"
                        {...accountForm.register('phone', {
                          pattern: {
                            value: /^[0-9]{10,11}$/,
                            message: 'Geçerli bir telefon numarası girin',
                          },
                        })}
                      />
                      {accountForm.formState.errors.phone && (
                        <span className={styles.error}>
                          {accountForm.formState.errors.phone.message}
                        </span>
                      )}
                    </div>

                    <div className={styles.formActions}>
                      <button 
                        type="submit" 
                        className={styles.saveButton}
                        disabled={updateAccountMutation.isLoading}
                      >
                        {updateAccountMutation.isLoading ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
                      </button>
                    </div>
                  </form>

                  <div className={styles.sectionDivider} />

                  <h3>Şifre Değiştir</h3>
                  <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className={styles.form}>
                    <div className={styles.formGroup}>
                      <label>Mevcut Şifre</label>
                      <input
                        type="password"
                        {...passwordForm.register('current_password', {
                          required: 'Mevcut şifre gerekli',
                        })}
                      />
                      {passwordForm.formState.errors.current_password && (
                        <span className={styles.error}>
                          {passwordForm.formState.errors.current_password.message}
                        </span>
                      )}
                    </div>

                    <div className={styles.formGroup}>
                      <label>Yeni Şifre</label>
                      <input
                        type="password"
                        {...passwordForm.register('new_password', {
                          required: 'Yeni şifre gerekli',
                          minLength: {
                            value: 8,
                            message: 'Şifre en az 8 karakter olmalı',
                          },
                        })}
                      />
                      {passwordForm.formState.errors.new_password && (
                        <span className={styles.error}>
                          {passwordForm.formState.errors.new_password.message}
                        </span>
                      )}
                    </div>

                    <div className={styles.formGroup}>
                      <label>Yeni Şifre (Tekrar)</label>
                      <input
                        type="password"
                        {...passwordForm.register('confirm_password', {
                          required: 'Şifre tekrarı gerekli',
                        })}
                      />
                      {passwordForm.formState.errors.confirm_password && (
                        <span className={styles.error}>
                          {passwordForm.formState.errors.confirm_password.message}
                        </span>
                      )}
                    </div>

                    <div className={styles.formActions}>
                      <button 
                        type="submit" 
                        className={styles.saveButton}
                        disabled={changePasswordMutation.isLoading}
                      >
                        {changePasswordMutation.isLoading ? 'Değiştiriliyor...' : 'Şifreyi Değiştir'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}

              {/* Bildirim Ayarları */}
              {activeTab === 'notifications' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={styles.settingsSection}
                >
                  <h2>Bildirim Tercihleri</h2>
                  
                  <form onSubmit={notificationForm.handleSubmit(onNotificationsSubmit)} className={styles.form}>
                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('email_notifications')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>E-posta Bildirimleri</strong>
                          <small>Önemli güncellemeleri e-posta ile al</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('push_notifications')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Anlık Bildirimler</strong>
                          <small>Tarayıcı bildirimlerini etkinleştir</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('match_notifications')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Eşleşme Bildirimleri</strong>
                          <small>Yeni eşleşmeler olduğunda bildir</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('message_notifications')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Mesaj Bildirimleri</strong>
                          <small>Yeni mesaj geldiğinde bildir</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('meeting_reminders')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Randevu Hatırlatmaları</strong>
                          <small>Yaklaşan randevular için hatırlat</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('review_reminders')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Değerlendirme Hatırlatmaları</strong>
                          <small>Randevu sonrası değerlendirme yapmayı hatırlat</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...notificationForm.register('marketing_emails')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Pazarlama E-postaları</strong>
                          <small>Kampanya ve yeniliklerden haberdar ol</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.formActions}>
                      <button 
                        type="submit" 
                        className={styles.saveButton}
                        disabled={updateNotificationsMutation.isLoading}
                      >
                        {updateNotificationsMutation.isLoading ? 'Kaydediliyor...' : 'Tercihleri Kaydet'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}

              {/* Gizlilik Ayarları */}
              {activeTab === 'privacy' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={styles.settingsSection}
                >
                  <h2>Gizlilik Ayarları</h2>
                  
                  <form onSubmit={privacyForm.handleSubmit(onPrivacySubmit)} className={styles.form}>
                    <div className={styles.formGroup}>
                      <label>Profil Görünürlüğü</label>
                      <select {...privacyForm.register('profile_visibility')}>
                        <option value="public">Herkese Açık</option>
                        <option value="matches_only">Sadece Eşleşmelere</option>
                        <option value="hidden">Gizli</option>
                      </select>
                    </div>

                    <div className={styles.formGroup}>
                      <label>Kimler Mesaj Gönderebilir?</label>
                      <select {...privacyForm.register('allow_messages_from')}>
                        <option value="everyone">Herkes</option>
                        <option value="matches_only">Sadece Eşleşmeler</option>
                        <option value="verified_only">Sadece Doğrulanmış Kullanıcılar</option>
                      </select>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...privacyForm.register('show_online_status')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Çevrimiçi Durumunu Göster</strong>
                          <small>Diğer kullanıcılar çevrimiçi olup olmadığınızı görebilir</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...privacyForm.register('show_distance')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Mesafeyi Göster</strong>
                          <small>Profilinizde yaklaşık mesafeniz görünür</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...privacyForm.register('show_age')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Yaşı Göster</strong>
                          <small>Profilinizde yaşınız görünür</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.checkboxGroup}>
                      <label className={styles.checkbox}>
                        <input
                          type="checkbox"
                          {...privacyForm.register('block_screenshots')}
                        />
                        <span className={styles.checkboxLabel}>
                          <strong>Ekran Görüntüsü Koruması</strong>
                          <small>Sohbetlerde ekran görüntüsü alınmasını engelle</small>
                        </span>
                      </label>
                    </div>

                    <div className={styles.formActions}>
                      <button 
                        type="submit" 
                        className={styles.saveButton}
                        disabled={updatePrivacyMutation.isLoading}
                      >
                        {updatePrivacyMutation.isLoading ? 'Kaydediliyor...' : 'Gizlilik Ayarlarını Kaydet'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}

              {/* Güvenlik Ayarları */}
              {activeTab === 'security' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={styles.settingsSection}
                >
                  <h2>Güvenlik Ayarları</h2>
                  
                  <div className={styles.securityStatus}>
                    <div className={styles.statusCard}>
                      <span className={styles.statusIcon}>📱</span>
                      <div className={styles.statusInfo}>
                        <h4>İki Faktörlü Doğrulama</h4>
                        <p>Hesabınıza ekstra güvenlik katmanı ekleyin</p>
                      </div>
                      <button className={styles.statusButton}>
                        Etkinleştir
                      </button>
                    </div>

                    <div className={styles.statusCard}>
                      <span className={styles.statusIcon}>🔑</span>
                      <div className={styles.statusInfo}>
                        <h4>Güvenilir Cihazlar</h4>
                        <p>Sadece güvenilir cihazlardan girişe izin ver</p>
                      </div>
                      <button className={styles.statusButton}>
                        Yönet
                      </button>
                    </div>

                    <div className={styles.statusCard}>
                      <span className={styles.statusIcon}>📧</span>
                      <div className={styles.statusInfo}>
                        <h4>Giriş Bildirimleri</h4>
                        <p>Yeni bir cihazdan giriş yapıldığında e-posta al</p>
                      </div>
                      <label className={styles.toggle}>
                        <input type="checkbox" defaultChecked />
                        <span className={styles.toggleSlider}></span>
                      </label>
                    </div>
                  </div>

                  <div className={styles.sectionDivider} />

                  <h3>Aktif Oturumlar</h3>
                  <div className={styles.sessionsList}>
                    <div className={styles.sessionItem}>
                      <div className={styles.sessionInfo}>
                        <span className={styles.sessionIcon}>💻</span>
                        <div>
                          <strong>Chrome - Windows</strong>
                          <p>İstanbul, Türkiye • Şu an aktif</p>
                        </div>
                      </div>
                      <span className={styles.currentBadge}>Mevcut</span>
                    </div>
                    <div className={styles.sessionItem}>
                      <div className={styles.sessionInfo}>
                        <span className={styles.sessionIcon}>📱</span>
                        <div>
                          <strong>iPhone 13 - Safari</strong>
                          <p>İstanbul, Türkiye • Son aktif: 2 saat önce</p>
                        </div>
                      </div>
                      <button className={styles.logoutButton}>Çıkış Yap</button>
                    </div>
                  </div>

                  <button className={styles.logoutAllButton}>
                    Tüm Cihazlardan Çıkış Yap
                  </button>
                </motion.div>
              )}

              {/* Engellenenler */}
              {activeTab === 'blocked' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={styles.settingsSection}
                >
                  <h2>Engellenen Kullanıcılar</h2>
                  
                  <div className={styles.blockedList}>
                    <div className={styles.emptyState}>
                      <span>🚫</span>
                      <p>Henüz engellenmiş kullanıcı bulunmuyor</p>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Verilerim */}
              {activeTab === 'data' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={styles.settingsSection}
                >
                  <h2>Verilerim</h2>
                  
                  <div className={styles.dataOptions}>
                    <div className={styles.dataCard}>
                      <span className={styles.dataIcon}>📥</span>
                      <div>
                        <h4>Verilerimi İndir</h4>
                        <p>Hesabınıza ait tüm verileri JSON formatında indirin</p>
                      </div>
                      <button className={styles.dataButton}>İndir</button>
                    </div>

                    <div className={styles.dataCard}>
                      <span className={styles.dataIcon}>📤</span>
                      <div>
                        <h4>Veri Aktarımı</h4>
                        <p>Verilerinizi başka bir hizmete aktarın</p>
                      </div>
                      <button className={styles.dataButton}>Aktar</button>
                    </div>

                    <div className={`${styles.dataCard} ${styles.danger}`}>
                      <span className={styles.dataIcon}>🗑️</span>
                      <div>
                        <h4>Verilerimi Sil</h4>
                        <p>Hesabınızdaki tüm verileri kalıcı olarak silin</p>
                      </div>
                      <button className={styles.dangerButton}>Verileri Sil</button>
                    </div>
                  </div>
                </motion.div>
              )}
            </section>
          </div>
        </div>
      </main>

      {/* Hesap Silme Onay Modalı */}
      {showDeleteConfirm && (
        <div className={styles.modalOverlay} onClick={() => setShowDeleteConfirm(false)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <h3>Hesabınızı Silmek İstediğinize Emin misiniz?</h3>
            <p>
              Bu işlem geri alınamaz. Tüm verileriniz, eşleşmeleriniz ve mesajlarınız 
              kalıcı olarak silinecektir.
            </p>
            <div className={styles.modalActions}>
              <button 
                className={styles.cancelButton}
                onClick={() => setShowDeleteConfirm(false)}
              >
                Vazgeç
              </button>
              <button 
                className={styles.deleteButton}
                onClick={handleDeleteAccount}
                disabled={deleteAccountMutation.isLoading}
              >
                {deleteAccountMutation.isLoading ? 'Siliniyor...' : 'Hesabımı Sil'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPage;