import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import Navbar from '../components/common/Navbar';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import styles from './VerificationPage.module.css';

const VerificationPage = () => {
  const { user, updateUser } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  
  const [activeStep, setActiveStep] = useState(1);
  const [uploadType, setUploadType] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [videoBlob, setVideoBlob] = useState(null);
  const [phoneCode, setPhoneCode] = useState('');
  const [emailCode, setEmailCode] = useState('');
  const [showPhoneInput, setShowPhoneInput] = useState(false);
  const [showEmailInput, setShowEmailInput] = useState(false);

  const { data: verifications, isLoading } = useQuery({
    queryKey: ['verifications'],
    queryFn: async () => {
      const response = await api.get('/verifications');
      return response.data.data;
    },
  });

  const verificationLevels = [
    {
      level: 'bronze',
      name: 'Bronz',
      icon: '🥉',
      color: '#CD7F32',
      requirements: [
        { type: 'phone', label: 'Telefon Doğrulama', icon: '📱' },
        { type: 'email', label: 'E-posta Doğrulama', icon: '📧' },
      ],
      benefits: ['Temel eşleşme özellikleri', 'Mesajlaşma', 'Profil oluşturma'],
    },
    {
      level: 'silver',
      name: 'Gümüş',
      icon: '🥈',
      color: '#C0C0C0',
      requirements: [
        { type: 'selfie', label: 'Selfie Doğrulama', icon: '🤳' },
      ],
      benefits: ['Öncelikli eşleşme', 'Daha fazla görünürlük', 'Gümüş rozeti'],
    },
    {
      level: 'gold',
      name: 'Altın',
      icon: '🥇',
      color: '#FFD700',
      requirements: [
        { type: 'id_card', label: 'Kimlik Doğrulama', icon: '🆔' },
      ],
      benefits: ['Altın rozeti', 'VIP destek', 'Özel etkinliklere erişim'],
    },
    {
      level: 'platinum',
      name: 'Platin',
      icon: '💎',
      color: '#E5E4E2',
      requirements: [
        { type: 'social_media', label: 'Sosyal Medya Bağlantısı', icon: '🌐' },
        { type: 'video_intro', label: 'Video Tanıtım', icon: '🎥' },
      ],
      benefits: ['Platin rozeti', 'Sınırsız eşleşme', 'Öncelikli müşteri hizmetleri'],
    },
  ];

  const sendVerificationCode = useMutation({
    mutationFn: async ({ type, value }) => {
      const response = await api.post('/verifications/send-code', { type, value });
      return response.data;
    },
    onSuccess: (_, variables) => {
      toast.success(`${variables.type === 'phone' ? 'SMS' : 'E-posta'} kodu gönderildi`);
      if (variables.type === 'phone') {
        setShowPhoneInput(true);
      } else {
        setShowEmailInput(true);
      }
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Kod gönderilemedi');
    },
  });

  const verifyCode = useMutation({
    mutationFn: async ({ type, code }) => {
      const response = await api.post('/verifications/verify-code', { type, code });
      return response.data;
    },
    onSuccess: (_, variables) => {
      toast.success(`${variables.type === 'phone' ? 'Telefon' : 'E-posta'} doğrulandı`);
      queryClient.invalidateQueries(['verifications']);
      updateUser({ ...user, verification_level: 'bronze' });
      setShowPhoneInput(false);
      setShowEmailInput(false);
      setPhoneCode('');
      setEmailCode('');
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Geçersiz kod');
    },
  });

  const uploadDocument = useMutation({
    mutationFn: async ({ type, file }) => {
      const formData = new FormData();
      formData.append('document', file);
      formData.append('type', type);
      
      const response = await api.post('/verifications/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return response.data;
    },
    onSuccess: (_, variables) => {
      toast.success(`${getVerificationLabel(variables.type)} belgesi yüklendi`);
      queryClient.invalidateQueries(['verifications']);
      setUploadType(null);
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Yükleme başarısız');
    },
  });

  const getVerificationLabel = (type) => {
    const labels = {
      phone: 'Telefon',
      email: 'E-posta',
      selfie: 'Selfie',
      id_card: 'Kimlik',
      social_media: 'Sosyal Medya',
      video_intro: 'Video Tanıtım',
    };
    return labels[type] || type;
  };

  const getVerificationStatus = (type) => {
    const verification = verifications?.find(v => v.type === type);
    if (!verification) return 'pending';
    return verification.status;
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file || !uploadType) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error('Dosya boyutu 10MB\'dan küçük olmalıdır');
      return;
    }

    setUploading(true);
    await uploadDocument.mutateAsync({ type: uploadType, file });
    setUploading(false);
  };

  const handleSendCode = (type) => {
    const value = type === 'phone' ? user?.phone : user?.email;
    if (!value) {
      toast.error(`${type === 'phone' ? 'Telefon numarası' : 'E-posta adresi'} bulunamadı`);
      return;
    }
    sendVerificationCode.mutate({ type, value });
  };

  const handleVerifyCode = (type) => {
    const code = type === 'phone' ? phoneCode : emailCode;
    if (!code) {
      toast.error('Doğrulama kodunu girin');
      return;
    }
    verifyCode.mutate({ type, code });
  };

  const startVideoRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      videoRef.current.srcObject = stream;
      videoRef.current.play();
      setRecording(true);

      // 30 saniye sonra otomatik durdur
      setTimeout(() => {
        stopVideoRecording();
      }, 30000);
    } catch (error) {
      toast.error('Kamera erişimi sağlanamadı');
    }
  };

  const stopVideoRecording = () => {
    const stream = videoRef.current.srcObject;
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    setRecording(false);
    
    // Video kaydı simülasyonu
    toast.success('Video kaydedildi');
    setVideoBlob(new Blob(['video'], { type: 'video/webm' }));
  };

  const currentLevel = user?.verification_level || 'bronze';
  const currentLevelIndex = verificationLevels.findIndex(l => l.level === currentLevel);

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className={styles.container}>
          <LoadingSkeleton type="verification" />
        </div>
      </>
    );
  }

  return (
    <div className={styles.verificationPage}>
      <Navbar />
      
      <main className={styles.main}>
        <div className={styles.container}>
          <h1>Hesap Doğrulama</h1>
          <p className={styles.subtitle}>
            Doğrulama seviyenizi yükselterek daha güvenli bir deneyim yaşayın
          </p>

          {/* Doğrulama Seviyeleri */}
          <div className={styles.levelsContainer}>
            {verificationLevels.map((level, index) => {
              const isUnlocked = index <= currentLevelIndex + 1;
              const isCompleted = index <= currentLevelIndex;
              const isCurrent = index === currentLevelIndex;

              return (
                <motion.div
                  key={level.level}
                  className={`${styles.levelCard} ${isCompleted ? styles.completed : ''} ${
                    isCurrent ? styles.current : ''
                  } ${!isUnlocked ? styles.locked : ''}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className={styles.levelHeader}>
                    <span className={styles.levelIcon}>{level.icon}</span>
                    <h3 style={{ color: level.color }}>{level.name}</h3>
                    {isCompleted && <span className={styles.completedBadge}>✅</span>}
                    {isCurrent && <span className={styles.currentBadge}>Aktif</span>}
                  </div>

                  <div className={styles.levelContent}>
                    <h4>Gereksinimler</h4>
                    <ul className={styles.requirements}>
                      {level.requirements.map(req => {
                        const status = getVerificationStatus(req.type);
                        return (
                          <li key={req.type} className={styles[status]}>
                            <span className={styles.reqIcon}>{req.icon}</span>
                            <span className={styles.reqLabel}>{req.label}</span>
                            <span className={styles.reqStatus}>
                              {status === 'approved' ? '✅' : 
                               status === 'pending' ? '⏳' : '❌'}
                            </span>
                            {isCurrent && status !== 'approved' && (
                              <button
                                className={styles.verifyButton}
                                onClick={() => {
                                  if (req.type === 'phone' || req.type === 'email') {
                                    handleSendCode(req.type);
                                  } else if (req.type === 'selfie' || req.type === 'id_card') {
                                    setUploadType(req.type);
                                    fileInputRef.current?.click();
                                  } else if (req.type === 'video_intro') {
                                    setActiveStep(3);
                                  }
                                }}
                              >
                                Doğrula
                              </button>
                            )}
                          </li>
                        );
                      })}
                    </ul>

                    <h4>Avantajlar</h4>
                    <ul className={styles.benefits}>
                      {level.benefits.map((benefit, i) => (
                        <li key={i}>
                          <span>✨</span> {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Telefon Doğrulama Modal */}
          {showPhoneInput && (
            <div className={styles.codeModal}>
              <div className={styles.codeModalContent}>
                <h3>Telefon Doğrulama</h3>
                <p>{user?.phone} numarasına gönderilen 6 haneli kodu girin</p>
                <input
                  type="text"
                  placeholder="123456"
                  maxLength={6}
                  value={phoneCode}
                  onChange={(e) => setPhoneCode(e.target.value)}
                  className={styles.codeInput}
                />
                <div className={styles.codeActions}>
                  <button onClick={() => handleVerifyCode('phone')}>Doğrula</button>
                  <button onClick={() => handleSendCode('phone')}>Kodu Tekrar Gönder</button>
                  <button onClick={() => setShowPhoneInput(false)}>İptal</button>
                </div>
              </div>
            </div>
          )}

          {/* E-posta Doğrulama Modal */}
          {showEmailInput && (
            <div className={styles.codeModal}>
              <div className={styles.codeModalContent}>
                <h3>E-posta Doğrulama</h3>
                <p>{user?.email} adresine gönderilen 6 haneli kodu girin</p>
                <input
                  type="text"
                  placeholder="123456"
                  maxLength={6}
                  value={emailCode}
                  onChange={(e) => setEmailCode(e.target.value)}
                  className={styles.codeInput}
                />
                <div className={styles.codeActions}>
                  <button onClick={() => handleVerifyCode('email')}>Doğrula</button>
                  <button onClick={() => handleSendCode('email')}>Kodu Tekrar Gönder</button>
                  <button onClick={() => setShowEmailInput(false)}>İptal</button>
                </div>
              </div>
            </div>
          )}

          {/* Video Tanıtım */}
          {activeStep === 3 && (
            <div className={styles.videoModal}>
              <div className={styles.videoModalContent}>
                <h3>Video Tanıtım</h3>
                <p>Kendinizi tanıtan 30 saniyelik bir video çekin</p>
                
                <div className={styles.videoPreview}>
                  <video ref={videoRef} width="400" height="300" />
                </div>

                <div className={styles.videoControls}>
                  {!recording ? (
                    <button onClick={startVideoRecording} className={styles.recordButton}>
                      🎥 Kayda Başla
                    </button>
                  ) : (
                    <button onClick={stopVideoRecording} className={styles.stopButton}>
                      ⏹️ Kaydı Durdur
                    </button>
                  )}
                </div>

                {videoBlob && (
                  <div className={styles.videoActions}>
                    <button 
                      onClick={() => {
                        uploadDocument.mutate({ 
                          type: 'video_intro', 
                          file: new File([videoBlob], 'intro.webm', { type: 'video/webm' })
                        });
                        setActiveStep(1);
                      }}
                    >
                      Videoyu Yükle
                    </button>
                    <button onClick={() => {
                      setVideoBlob(null);
                      setActiveStep(1);
                    }}>
                      İptal
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Gizli Dosya Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileUpload}
          />
        </div>
      </main>
    </div>
  );
};

export default VerificationPage;