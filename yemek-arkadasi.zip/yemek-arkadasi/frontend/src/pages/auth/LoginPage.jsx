import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { useAuth } from '../../context/AuthContext';
import styles from './Auth.module.css';

const LoginPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { register, handleSubmit, formState: { errors } } = useForm();

  const onSubmit = async (data) => {
    setIsLoading(true);
    const result = await login(data.identifier, data.password);
    setIsLoading(false);
    
    if (!result.success) {
      // Hata zaten context'te toast ile gösteriliyor
    }
  };

  return (
    <div className={styles.authPage}>
      <motion.div
        className={styles.authCard}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className={styles.authHeader}>
          <Link to="/" className={styles.backButton}>
            ← Ana Sayfa
          </Link>
          <h1>Hoş Geldiniz</h1>
          <p>Hesabınıza giriş yapın</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className={styles.authForm}>
          <div className={styles.formGroup}>
            <label htmlFor="identifier">E-posta veya Telefon</label>
            <input
              id="identifier"
              type="text"
              placeholder="ornek@email.com veya 5XXXXXXXXX"
              {...register('identifier', {
                required: 'E-posta veya telefon numarası gerekli',
              })}
              className={errors.identifier ? styles.error : ''}
            />
            {errors.identifier && (
              <span className={styles.errorMessage}>{errors.identifier.message}</span>
            )}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="password">Şifre</label>
            <input
              id="password"
              type="password"
              placeholder="••••••••"
              {...register('password', {
                required: 'Şifre gerekli',
              })}
              className={errors.password ? styles.error : ''}
            />
            {errors.password && (
              <span className={styles.errorMessage}>{errors.password.message}</span>
            )}
          </div>

          <div className={styles.formOptions}>
            <label className={styles.checkbox}>
              <input type="checkbox" />
              <span>Beni hatırla</span>
            </label>
            <Link to="/forgot-password" className={styles.forgotPassword}>
              Şifremi unuttum
            </Link>
          </div>

          <button
            type="submit"
            className={styles.submitButton}
            disabled={isLoading}
          >
            {isLoading ? (
              <span className={styles.loadingSpinner}>⟳</span>
            ) : (
              'Giriş Yap'
            )}
          </button>
        </form>

        <div className={styles.authFooter}>
          <p>
            Hesabınız yok mu?{' '}
            <Link to="/register" className={styles.link}>
              Hemen Kaydolun
            </Link>
          </p>
        </div>

        <div className={styles.socialLogin}>
          <p>veya şununla devam et</p>
          <div className={styles.socialButtons}>
            <button className={styles.googleButton}>
              <span>G</span> Google
            </button>
            <button className={styles.appleButton}>
              <span></span> Apple
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;