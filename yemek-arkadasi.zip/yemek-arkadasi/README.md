# 🍽️ Yemek Arkadaşı

Güvenli sosyal yemek buluşma platformu. Yalnız yemek yemek istemeyen, güvenli ortamda yeni insanlar tanımak isteyen kullanıcılar için geliştirilmiş, güvenlik odaklı bir platform.

## ✨ Özellikler

### 🛡️ Güvenlik
- **Kademeli Doğrulama Sistemi**: Bronz, Gümüş, Altın, Platin seviyeleri
- **Puanlama ve Değerlendirme**: Her buluşma sonrası karşılıklı değerlendirme
- **Kademeli Konum Paylaşımı**: Sohbet ilerledikçe artan konum detayı
- **Acil Durum Butonu**: Her ekranda gizli panik butonu
- **Güvenilir Kişi Bildirimi**: Acil durumda otomatik konum gönderme

### 👥 Kullanıcı Özellikleri
- Keşfet ve eşleş
- Gerçek zamanlı mesajlaşma
- Randevu planlama
- Restoran keşfi ve rezervasyon
- Profil özelleştirme
- Değerlendirme ve yorumlar

### 📱 Teknik Özellikler
- Responsive tasarım (mobile-first)
- PWA desteği
- Gerçek zamanlı bildirimler
- Offline mod desteği
- Dark mode

## 🚀 Kurulum

### Gereksinimler
- Node.js 18+
- npm veya yarn
- SQLite3

### Backend Kurulumu

```bash
cd backend
npm install
npm run dev