-- Yemek Arkadaşı Veritabanı Şeması

-- Kullanıcılar tablosu
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    age INTEGER CHECK (age >= 18),
    gender TEXT CHECK (gender IN ('erkek', 'kadın', 'diğer', 'belirtmek_istemiyorum')),
    avatar_url TEXT,
    bio TEXT,
    verification_level TEXT DEFAULT 'bronze' CHECK (verification_level IN ('bronze', 'silver', 'gold', 'platinum')),
    rating_average REAL DEFAULT 0.0,
    total_meals INTEGER DEFAULT 0,
    total_reviews INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Profil bilgileri tablosu
CREATE TABLE IF NOT EXISTS profiles (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    food_preferences TEXT, -- JSON formatında: {"mutfaklar": [], "diyet": [], "alerjiler": []}
    budget_range TEXT CHECK (budget_range IN ('ekonomik', 'orta', 'pahalı', 'farketmez')),
    conversation_style TEXT CHECK (conversation_style IN ('sakin', 'normal', 'eğlenceli')),
    availability TEXT, -- JSON formatında: {"gunler": [], "saatler": []}
    location_lat REAL,
    location_lng REAL,
    location_city TEXT,
    location_district TEXT,
    smoking BOOLEAN DEFAULT 0,
    alcohol_preference TEXT CHECK (alcohol_preference IN ('kullanmam', 'nadiren', 'sosyal', 'sık')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Doğrulama işlemleri tablosu
CREATE TABLE IF NOT EXISTS verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT CHECK (type IN ('phone', 'email', 'selfie', 'id_card', 'social_media', 'video_intro')),
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    document_url TEXT,
    verified_at DATETIME,
    verified_by INTEGER REFERENCES users(id),
    rejection_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, type)
);

-- Eşleşmeler tablosu
CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id_1 INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_id_2 INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'blocked')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    matched_at DATETIME,
    rejected_at DATETIME,
    UNIQUE(user_id_1, user_id_2)
);

-- Mesajlar tablosu
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
    sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    content_type TEXT DEFAULT 'text' CHECK (content_type IN ('text', 'image', 'location_share')),
    location_data TEXT, -- JSON formatında konum bilgisi
    is_read BOOLEAN DEFAULT 0,
    read_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Buluşmalar tablosu
CREATE TABLE IF NOT EXISTS meetings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
    restaurant_id INTEGER REFERENCES restaurants(id),
    scheduled_at DATETIME NOT NULL,
    duration_minutes INTEGER DEFAULT 120,
    status TEXT DEFAULT 'planned' CHECK (status IN ('planned', 'confirmed', 'active', 'completed', 'cancelled', 'no_show')),
    safety_checklist_completed BOOLEAN DEFAULT 0,
    created_by INTEGER NOT NULL REFERENCES users(id),
    cancelled_by INTEGER REFERENCES users(id),
    cancellation_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Değerlendirmeler tablosu
CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    reviewer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reviewed_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    criteria TEXT NOT NULL, -- JSON formatında: {"dogruluk": 5, "dakiklik": 4, "davranis": 5, "guvenlik": 4, "sohbet": 5}
    comment TEXT,
    is_anonymous BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(meeting_id, reviewer_id, reviewed_id)
);

-- Restoranlar tablosu
CREATE TABLE IF NOT EXISTS restaurants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    cuisine_type TEXT NOT NULL,
    price_range TEXT CHECK (price_range IN ('ekonomik', 'orta', 'pahalı')),
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    rating REAL DEFAULT 0.0,
    image_url TEXT,
    phone TEXT,
    website TEXT,
    opening_hours TEXT, -- JSON formatında
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Acil durum bildirimleri tablosu
CREATE TABLE IF NOT EXISTS emergency_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    meeting_id INTEGER REFERENCES meetings(id),
    alert_type TEXT CHECK (alert_type IN ('panic_button', 'checkin_missed', 'sos')),
    latitude REAL,
    longitude REAL,
    trusted_contacts_notified BOOLEAN DEFAULT 0,
    emergency_services_notified BOOLEAN DEFAULT 0,
    resolved_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Güvenilir kişiler tablosu
CREATE TABLE IF NOT EXISTS trusted_contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    relation TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Güvenlik kontrol listesi
CREATE TABLE IF NOT EXISTS safety_checklists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    checklist_items TEXT NOT NULL, -- JSON formatında onaylanan maddeler
    completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(meeting_id, user_id)
);

-- İndeksler
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_matches_users ON matches(user_id_1, user_id_2);
CREATE INDEX idx_messages_match ON messages(match_id);
CREATE INDEX idx_meetings_match ON meetings(match_id);
CREATE INDEX idx_meetings_status ON meetings(status);
CREATE INDEX idx_reviews_reviewed ON reviews(reviewed_id);
CREATE INDEX idx_emergency_user ON emergency_alerts(user_id);