/**
 * Veritabanı Yapılandırması
 * @description SQLite veritabanı bağlantısı ve yardımcı fonksiyonlar
 */

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Veritabanı dosya yolu
const dbPath = path.join(__dirname, '../../database/yemek_arkadasi.db');

// Data klasörünün varlığını kontrol et
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}

// Veritabanı bağlantısı oluştur
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Veritabanı bağlantı hatası:', err.message);
    } else {
        console.log('✅ SQLite veritabanına bağlanıldı');
        
        // Yabancı anahtar kısıtlamalarını aktif et
        db.run('PRAGMA foreign_keys = ON');
        
        // Veritabanı şemasını oluştur
        initializeDatabase();
    }
});

/**
 * Veritabanı şemasını oluştur
 */
function initializeDatabase() {
    const schemaPath = path.join(__dirname, '../../database/schema.sql');
    
    if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        
        db.exec(schema, (err) => {
            if (err) {
                console.error('❌ Şema oluşturma hatası:', err.message);
            } else {
                console.log('✅ Veritabanı şeması oluşturuldu');
                // Örnek verileri ekle
                seedDatabase();
            }
        });
    }
}

/**
 * Örnek verileri ekle
 */
function seedDatabase() {
    // Restoran örnekleri
    const sampleRestaurants = [
        ['Köşebaşı Kebap', 'Atatürk Cad. No:123, İstanbul', 'Türk Mutfağı', 'orta', 41.0082, 28.9784, 4.5],
        ['SushiCo', 'Bağdat Cad. No:456, İstanbul', 'Japon Mutfağı', 'pahalı', 40.9862, 29.0341, 4.8],
        ['Pizza Locale', 'İstiklal Cad. No:789, İstanbul', 'İtalyan Mutfağı', 'ekonomik', 41.0351, 28.9833, 4.3],
        ['Vejetaryen Dünyası', 'Moda Cad. No:321, İstanbul', 'Vejetaryen', 'orta', 40.9855, 29.0252, 4.6],
        ['Mekan Burger', 'Nispetiye Cad. No:654, İstanbul', 'Amerikan Mutfağı', 'orta', 41.0687, 29.0198, 4.4]
    ];

    const insertRestaurant = db.prepare(`
        INSERT OR IGNORE INTO restaurants (name, address, cuisine_type, price_range, latitude, longitude, rating)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    sampleRestaurants.forEach(restaurant => {
        insertRestaurant.run(restaurant);
    });

    insertRestaurant.finalize();
    console.log('📊 Örnek restoran verileri eklendi');
}

/**
 * Promise tabanlı sorgu çalıştırma
 * @param {string} sql - SQL sorgusu
 * @param {Array} params - Parametreler
 * @returns {Promise} Sorgu sonucu
 */
function query(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
}

/**
 * Promise tabanlı tek kayıt döndüren sorgu
 * @param {string} sql - SQL sorgusu
 * @param {Array} params - Parametreler
 * @returns {Promise} Tek kayıt
 */
function queryOne(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) {
                reject(err);
            } else {
                resolve(row);
            }
        });
    });
}

/**
 * Promise tabanlı INSERT/UPDATE/DELETE sorgusu
 * @param {string} sql - SQL sorgusu
 * @param {Array} params - Parametreler
 * @returns {Promise} İşlem sonucu (lastID, changes)
 */
function run(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({
                    lastID: this.lastID,
                    changes: this.changes
                });
            }
        });
    });
}

/**
 * Transaction başlat
 * @returns {Promise}
 */
function beginTransaction() {
    return run('BEGIN TRANSACTION');
}

/**
 * Transaction'ı onayla
 * @returns {Promise}
 */
function commit() {
    return run('COMMIT');
}

/**
 * Transaction'ı geri al
 * @returns {Promise}
 */
function rollback() {
    return run('ROLLBACK');
}

module.exports = {
    db,
    query,
    queryOne,
    run,
    beginTransaction,
    commit,
    rollback
};