/**
 * Global Error Handler Middleware
 * @description Tüm hataları yakalar ve formatlı response döner
 */

/**
 * Global hata yakalama middleware'i
 */
function errorHandler(err, req, res, next) {
    console.error('❌ Hata yakalandı:', {
        message: err.message,
        stack: err.stack,
        url: req.url,
        method: req.method,
        ip: req.ip
    });

    // Validation hatası
    if (err.name === 'ValidationError') {
        return res.status(400).json({
            success: false,
            message: 'Validasyon hatası',
            errors: err.errors
        });
    }

    // SQLite hataları
    if (err.code === 'SQLITE_CONSTRAINT') {
        if (err.message.includes('UNIQUE')) {
            return res.status(409).json({
                success: false,
                message: 'Bu kayıt zaten mevcut'
            });
        }
        
        if (err.message.includes('FOREIGN KEY')) {
            return res.status(400).json({
                success: false,
                message: 'Geçersiz referans'
            });
        }
    }

    // JWT hataları (auth middleware'den gelen)
    if (err.name === 'JsonWebTokenError') {
        return res.status(401).json({
            success: false,
            message: 'Geçersiz token'
        });
    }

    if (err.name === 'TokenExpiredError') {
        return res.status(401).json({
            success: false,
            message: 'Oturum süresi doldu, lütfen tekrar giriş yapın'
        });
    }

    // Multer dosya yükleme hataları
    if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
            success: false,
            message: 'Dosya boyutu çok büyük (maksimum 5MB)'
        });
    }

    if (err.code === 'LIMIT_UNEXPECTED_FILE') {
        return res.status(400).json({
            success: false,
            message: 'Beklenmeyen dosya alanı'
        });
    }

    // Varsayılan hata response'u
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Sunucu hatası oluştu';

    res.status(statusCode).json({
        success: false,
        message: message,
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
}

/**
 * Özel hata sınıfı
 */
class AppError extends Error {
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.name = this.constructor.name;
        Error.captureStackTrace(this, this.constructor);
    }
}

module.exports = errorHandler;
module.exports.AppError = AppError;