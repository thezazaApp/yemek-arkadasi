/**
 * Authentication Middleware
 * @description JWT token doğrulama ve kullanıcı yetkilendirme
 */

const jwt = require('jsonwebtoken');
const db = require('../config/database');

/**
 * JWT token doğrulama middleware'i
 * @param {Object} req - Express request objesi
 * @param {Object} res - Express response objesi
 * @param {Function} next - Sonraki middleware
 */
async function authMiddleware(req, res, next) {
    try {
        // Authorization header'ı kontrol et
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: 'Yetkilendirme token\'ı bulunamadı'
            });
        }

        // Token'ı al
        const token = authHeader.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Geçersiz token formatı'
            });
        }

        // Token'ı doğrula
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'yemek-arkadasi-secret-key-2024');
        
        // Kullanıcıyı veritabanından kontrol et
        const user = await db.queryOne(
            `SELECT id, email, phone, full_name, verification_level, rating_average, 
                    total_meals, is_active, avatar_url
             FROM users 
             WHERE id = ? AND is_active = 1`,
            [decoded.userId]
        );

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Kullanıcı bulunamadı veya hesap deaktif'
            });
        }

        // Kullanıcı bilgilerini request'e ekle
        req.user = user;
        req.userId = user.id;

        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                success: false,
                message: 'Geçersiz token'
            });
        } else if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Token süresi doldu, lütfen tekrar giriş yapın'
            });
        }

        console.error('Auth middleware hatası:', error);
        res.status(500).json({
            success: false,
            message: 'Yetkilendirme sırasında bir hata oluştu'
        });
    }
}

/**
 * Doğrulama seviyesi kontrolü middleware'i
 * @param {Array} allowedLevels - İzin verilen doğrulama seviyeleri
 */
function requireVerificationLevel(...allowedLevels) {
    return (req, res, next) => {
        const userLevel = req.user.verification_level;
        
        if (!allowedLevels.includes(userLevel)) {
            return res.status(403).json({
                success: false,
                message: `Bu işlem için en az ${allowedLevels.join(' veya ')} doğrulama seviyesi gereklidir`,
                currentLevel: userLevel,
                requiredLevels: allowedLevels
            });
        }
        
        next();
    };
}

/**
 * Opsiyonel authentication (token varsa doğrula, yoksa devam et)
 */
async function optionalAuth(req, res, next) {
    try {
        const authHeader = req.headers.authorization;
        
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.split(' ')[1];
            
            if (token) {
                const decoded = jwt.verify(token, process.env.JWT_SECRET || 'yemek-arkadasi-secret-key-2024');
                const user = await db.queryOne(
                    'SELECT id, email, full_name, verification_level FROM users WHERE id = ? AND is_active = 1',
                    [decoded.userId]
                );
                
                if (user) {
                    req.user = user;
                    req.userId = user.id;
                }
            }
        }
        
        next();
    } catch (error) {
        // Token geçersiz olsa bile devam et (opsiyonel auth)
        next();
    }
}

module.exports = authMiddleware;
module.exports.requireVerificationLevel = requireVerificationLevel;
module.exports.optionalAuth = optionalAuth;