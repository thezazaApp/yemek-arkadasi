/**
 * Validation Middleware
 * @description Express-validator ile input doğrulama
 */

const { body, param, query, validationResult } = require('express-validator');

/**
 * Validation hatalarını kontrol et ve formatla
 */
const validateRequest = (req, res, next) => {
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validasyon hatası',
            errors: errors.array().map(err => ({
                field: err.path,
                message: err.msg
            }))
        });
    }
    
    next();
};

/**
 * Kayıt validasyon kuralları
 */
const registerValidation = [
    body('email')
        .isEmail().withMessage('Geçerli bir e-posta adresi giriniz')
        .normalizeEmail()
        .isLength({ max: 255 }).withMessage('E-posta çok uzun'),
    
    body('phone')
        .matches(/^[0-9]{10,11}$/).withMessage('Geçerli bir telefon numarası giriniz (10-11 haneli)')
        .trim(),
    
    body('password')
        .isLength({ min: 8 }).withMessage('Şifre en az 8 karakter olmalıdır')
        .matches(/[A-Z]/).withMessage('Şifre en az bir büyük harf içermelidir')
        .matches(/[a-z]/).withMessage('Şifre en az bir küçük harf içermelidir')
        .matches(/[0-9]/).withMessage('Şifre en az bir rakam içermelidir')
        .matches(/[!@#$%^&*(),.?":{}|<>]/).withMessage('Şifre en az bir özel karakter içermelidir'),
    
    body('full_name')
        .isLength({ min: 3, max: 100 }).withMessage('Ad soyad 3-100 karakter arasında olmalıdır')
        .matches(/^[a-zA-ZğüşıöçĞÜŞİÖÇ\s]+$/).withMessage('Ad soyad sadece harf içermelidir')
        .trim(),
    
    body('age')
        .isInt({ min: 18, max: 100 }).withMessage('Yaş 18-100 arasında olmalıdır'),
    
    body('gender')
        .isIn(['erkek', 'kadın', 'diğer', 'belirtmek_istemiyorum']).withMessage('Geçerli bir cinsiyet seçiniz'),
    
    validateRequest
];

/**
 * Giriş validasyon kuralları
 */
const loginValidation = [
    body('identifier')
        .notEmpty().withMessage('E-posta veya telefon numarası giriniz')
        .trim(),
    
    body('password')
        .notEmpty().withMessage('Şifre giriniz'),
    
    validateRequest
];

/**
 * Profil güncelleme validasyon kuralları
 */
const profileUpdateValidation = [
    body('bio')
        .optional()
        .isLength({ max: 500 }).withMessage('Biyografi en fazla 500 karakter olabilir')
        .trim(),
    
    body('food_preferences')
        .optional()
        .isJSON().withMessage('Geçersiz JSON formatı'),
    
    body('budget_range')
        .optional()
        .isIn(['ekonomik', 'orta', 'pahalı', 'farketmez']).withMessage('Geçerli bir bütçe aralığı seçiniz'),
    
    validateRequest
];

/**
 * Mesaj validasyon kuralları
 */
const messageValidation = [
    body('content')
        .notEmpty().withMessage('Mesaj içeriği boş olamaz')
        .isLength({ max: 1000 }).withMessage('Mesaj en fazla 1000 karakter olabilir')
        .trim(),
    
    body('match_id')
        .isInt().withMessage('Geçerli bir eşleşme ID\'si giriniz'),
    
    validateRequest
];

/**
 * Randevu oluşturma validasyon kuralları
 */
const meetingValidation = [
    body('match_id')
        .isInt().withMessage('Geçerli bir eşleşme ID\'si giriniz'),
    
    body('restaurant_id')
        .optional()
        .isInt().withMessage('Geçerli bir restoran ID\'si giriniz'),
    
    body('scheduled_at')
        .isISO8601().withMessage('Geçerli bir tarih formatı giriniz')
        .custom(value => {
            const date = new Date(value);
            const now = new Date();
            
            if (date < now) {
                throw new Error('Randevu tarihi geçmiş bir tarih olamaz');
            }
            
            const maxDate = new Date();
            maxDate.setMonth(maxDate.getMonth() + 3);
            
            if (date > maxDate) {
                throw new Error('Randevu en fazla 3 ay sonrası için oluşturulabilir');
            }
            
            return true;
        }),
    
    body('duration_minutes')
        .optional()
        .isInt({ min: 30, max: 300 }).withMessage('Süre 30-300 dakika arasında olmalıdır'),
    
    validateRequest
];

/**
 * Değerlendirme validasyon kuralları
 */
const reviewValidation = [
    body('meeting_id')
        .isInt().withMessage('Geçerli bir buluşma ID\'si giriniz'),
    
    body('rating')
        .isInt({ min: 1, max: 5 }).withMessage('Puan 1-5 arasında olmalıdır'),
    
    body('criteria')
        .isJSON().withMessage('Kriterler JSON formatında olmalıdır')
        .custom(value => {
            const criteria = JSON.parse(value);
            const requiredFields = ['dogruluk', 'dakiklik', 'davranis', 'guvenlik', 'sohbet'];
            
            for (const field of requiredFields) {
                if (!criteria[field] || criteria[field] < 1 || criteria[field] > 5) {
                    throw new Error(`${field} kriteri 1-5 arasında bir değer olmalıdır`);
                }
            }
            
            return true;
        }),
    
    body('comment')
        .optional()
        .isLength({ max: 500 }).withMessage('Yorum en fazla 500 karakter olabilir')
        .trim(),
    
    validateRequest
];

module.exports = {
    validateRequest,
    registerValidation,
    loginValidation,
    profileUpdateValidation,
    messageValidation,
    meetingValidation,
    reviewValidation
};