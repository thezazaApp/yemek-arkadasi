/**
 * Socket.io Handler
 * @description Gerçek zamanlı mesajlaşma ve bildirim yönetimi
 */

const jwt = require('jsonwebtoken');

// Aktif bağlantıları tut
const activeUsers = new Map(); // userId -> socketId[]
const userSockets = new Map(); // socketId -> userId

/**
 * Socket.io bağlantı yönetimi
 * @param {Object} io - Socket.io server instance
 * @param {Object} db - Veritabanı bağlantısı
 */
function socketHandler(io, db) {
    
    // Authentication middleware for Socket.io
    io.use(async (socket, next) => {
        try {
            const token = socket.handshake.auth.token;
            
            if (!token) {
                return next(new Error('Authentication token gerekli'));
            }

            const decoded = jwt.verify(token, process.env.JWT_SECRET || 'yemek-arkadasi-secret-key-2024');
            
            // Kullanıcıyı veritabanından kontrol et
            const user = await db.queryOne(
                'SELECT id, full_name, verification_level FROM users WHERE id = ? AND is_active = 1',
                [decoded.userId]
            );

            if (!user) {
                return next(new Error('Kullanıcı bulunamadı'));
            }

            socket.userId = user.id;
            socket.user = user;
            next();
        } catch (error) {
            next(new Error('Geçersiz token'));
        }
    });

    io.on('connection', (socket) => {
        const userId = socket.userId;
        
        console.log(`🟢 Kullanıcı bağlandı: ${userId} (${socket.user.full_name})`);

        // Aktif kullanıcıları güncelle
        if (!activeUsers.has(userId)) {
            activeUsers.set(userId, new Set());
        }
        activeUsers.get(userId).add(socket.id);
        userSockets.set(socket.id, userId);

        // Kullanıcının online olduğunu bildir
        socket.broadcast.emit('user:online', { userId });

        /**
         * Özel odaya katıl (eşleşme için)
         */
        socket.on('room:join', async (data) => {
            const { matchId } = data;
            
            // Eşleşmeyi kontrol et
            const match = await db.queryOne(
                `SELECT * FROM matches 
                 WHERE id = ? AND (user_id_1 = ? OR user_id_2 = ?) AND status = 'accepted'`,
                [matchId, userId, userId]
            );

            if (!match) {
                socket.emit('error', { message: 'Bu eşleşmeye erişim izniniz yok' });
                return;
            }

            const roomName = `match:${matchId}`;
            socket.join(roomName);
            
            // Diğer kullanıcıya bildirim gönder
            const otherUserId = match.user_id_1 === userId ? match.user_id_2 : match.user_id_1;
            socket.to(roomName).emit('user:joined', { userId, roomName });

            console.log(`👥 Kullanıcı ${userId} odaya katıldı: ${roomName}`);
        });

        /**
         * Mesaj gönderme
         */
        socket.on('message:send', async (data) => {
            const { matchId, content, contentType = 'text' } = data;

            try {
                // Eşleşmeyi kontrol et
                const match = await db.queryOne(
                    `SELECT * FROM matches 
                     WHERE id = ? AND (user_id_1 = ? OR user_id_2 = ?) AND status = 'accepted'`,
                    [matchId, userId, userId]
                );

                if (!match) {
                    socket.emit('error', { message: 'Bu eşleşmeye mesaj gönderemezsiniz' });
                    return;
                }

                // Mesajı kaydet
                const result = await db.run(
                    `INSERT INTO messages (match_id, sender_id, content, content_type)
                     VALUES (?, ?, ?, ?)`,
                    [matchId, userId, content, contentType]
                );

                const message = {
                    id: result.lastID,
                    matchId,
                    senderId: userId,
                    content,
                    contentType,
                    createdAt: new Date().toISOString()
                };

                // Odaya mesajı gönder
                const roomName = `match:${matchId}`;
                io.to(roomName).emit('message:received', message);

                // Okunmamış mesaj bildirimi
                const otherUserId = match.user_id_1 === userId ? match.user_id_2 : match.user_id_1;
                
                if (activeUsers.has(otherUserId)) {
                    io.to(Array.from(activeUsers.get(otherUserId))).emit('notification:new_message', {
                        matchId,
                        senderId: userId,
                        preview: content.substring(0, 50)
                    });
                }

                console.log(`💬 Mesaj gönderildi: ${userId} -> match:${matchId}`);

            } catch (error) {
                console.error('Mesaj gönderme hatası:', error);
                socket.emit('error', { message: 'Mesaj gönderilemedi' });
            }
        });

        /**
         * Mesaj okundu bildirimi
         */
        socket.on('message:read', async (data) => {
            const { messageId, matchId } = data;

            try {
                await db.run(
                    `UPDATE messages SET is_read = 1, read_at = CURRENT_TIMESTAMP 
                     WHERE id = ? AND match_id = ? AND sender_id != ?`,
                    [messageId, matchId, userId]
                );

                const roomName = `match:${matchId}`;
                socket.to(roomName).emit('message:read_confirmation', {
                    messageId,
                    readBy: userId,
                    readAt: new Date().toISOString()
                });

            } catch (error) {
                console.error('Okundu bildirimi hatası:', error);
            }
        });

        /**
         * Yazıyor... bildirimi
         */
        socket.on('typing:start', (data) => {
            const { matchId } = data;
            const roomName = `match:${matchId}`;
            socket.to(roomName).emit('typing:update', {
                userId,
                isTyping: true
            });
        });

        socket.on('typing:stop', (data) => {
            const { matchId } = data;
            const roomName = `match:${matchId}`;
            socket.to(roomName).emit('typing:update', {
                userId,
                isTyping: false
            });
        });

        /**
         * Konum paylaşımı
         */
        socket.on('location:share', async (data) => {
            const { matchId, latitude, longitude, shareType } = data;

            try {
                const roomName = `match:${matchId}`;
                
                const locationData = {
                    latitude,
                    longitude,
                    shareType, // 'approximate' veya 'exact'
                    timestamp: new Date().toISOString()
                };

                // Konum bilgisini mesaj olarak kaydet
                await db.run(
                    `INSERT INTO messages (match_id, sender_id, content, content_type, location_data)
                     VALUES (?, ?, ?, 'location_share', ?)`,
                    [matchId, userId, `${shareType === 'approximate' ? 'Yaklaşık' : 'Tam'} konum paylaşıldı`, JSON.stringify(locationData)]
                );

                socket.to(roomName).emit('location:received', {
                    userId,
                    ...locationData
                });

            } catch (error) {
                console.error('Konum paylaşım hatası:', error);
                socket.emit('error', { message: 'Konum paylaşılamadı' });
            }
        });

        /**
         * Acil durum bildirimi (Panik butonu)
         */
        socket.on('emergency:panic', async (data) => {
            const { meetingId, latitude, longitude } = data;

            try {
                // Acil durum kaydı oluştur
                await db.run(
                    `INSERT INTO emergency_alerts (user_id, meeting_id, alert_type, latitude, longitude)
                     VALUES (?, ?, 'panic_button', ?, ?)`,
                    [userId, meetingId, latitude, longitude]
                );

                // Güvenilir kişileri bul
                const trustedContacts = await db.query(
                    'SELECT * FROM trusted_contacts WHERE user_id = ? AND is_active = 1',
                    [userId]
                );

                // Admin'e bildir (socket.io ile)
                io.to('admin:room').emit('emergency:alert', {
                    userId,
                    meetingId,
                    latitude,
                    longitude,
                    timestamp: new Date().toISOString()
                });

                console.log(`🚨 ACİL DURUM! Kullanıcı ${userId} panik butonuna bastı`);

                socket.emit('emergency:acknowledged', {
                    message: 'Acil durum bildirimi alındı, güvenilir kişilerinize haber veriliyor',
                    contactsNotified: trustedContacts.length
                });

            } catch (error) {
                console.error('Acil durum bildirimi hatası:', error);
                socket.emit('error', { message: 'Acil durum bildirimi gönderilemedi' });
            }
        });

        /**
         * Bağlantı kopması
         */
        socket.on('disconnect', () => {
            console.log(`🔴 Kullanıcı ayrıldı: ${userId} (${socket.user?.full_name || 'Bilinmeyen'})`);

            // Aktif kullanıcı listesinden çıkar
            if (activeUsers.has(userId)) {
                activeUsers.get(userId).delete(socket.id);
                
                if (activeUsers.get(userId).size === 0) {
                    activeUsers.delete(userId);
                    // Kullanıcının offline olduğunu bildir
                    socket.broadcast.emit('user:offline', { userId });
                }
            }

            userSockets.delete(socket.id);
        });

        // Admin odasına katıl (admin kullanıcıları için)
        if (socket.user.verification_level === 'platinum' && socket.user.isAdmin) {
            socket.join('admin:room');
        }
    });
}

module.exports = socketHandler;