/**
 * Yemek Arkadaşı - Ana Sunucu Dosyası
 * @description Express.js ile REST API ve Socket.io entegrasyonu
 * @version 1.0.0
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');
const http = require('http');
const socketIO = require('socket.io');
require('dotenv').config();

// Veritabanı bağlantısı
const db = require('./config/database');

// Middleware'ler
const authMiddleware = require('./middleware/auth');
const errorHandler = require('./middleware/errorHandler');
const validationMiddleware = require('./middleware/validation');

// Route'lar
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const matchRoutes = require('./routes/matches');
const messageRoutes = require('./routes/messages');
const meetingRoutes = require('./routes/meetings');
const reviewRoutes = require('./routes/reviews');
const restaurantRoutes = require('./routes/restaurants');
const verificationRoutes = require('./routes/verifications');
const emergencyRoutes = require('./routes/emergency');

// Socket.io handler
const socketHandler = require('./socket');

// Express uygulaması oluştur
const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
    cors: {
        origin: process.env.CLIENT_URL || "http://localhost:5173",
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Rate limiting yapılandırması
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 dakika
    max: 100, // Her IP için 100 istek limiti
    message: 'Çok fazla istek gönderildi. Lütfen daha sonra tekrar deneyin.',
    standardHeaders: true,
    legacyHeaders: false,
});

// Middleware'leri uygula
app.use(helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }
}));
app.use(cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    credentials: true
}));
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use('/api', limiter);

// Statik dosyalar için uploads klasörü
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API Route'larını tanımla
app.use('/api/auth', authRoutes);
app.use('/api/users', authMiddleware, userRoutes);
app.use('/api/matches', authMiddleware, matchRoutes);
app.use('/api/messages', authMiddleware, messageRoutes);
app.use('/api/meetings', authMiddleware, meetingRoutes);
app.use('/api/reviews', authMiddleware, reviewRoutes);
app.use('/api/restaurants', authMiddleware, restaurantRoutes);
app.use('/api/verifications', authMiddleware, verificationRoutes);
app.use('/api/emergency', authMiddleware, emergencyRoutes);

// Sağlık kontrolü endpoint'i
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Aradığınız endpoint bulunamadı'
    });
});

// Hata yakalama middleware'i
app.use(errorHandler);

// Socket.io bağlantı yönetimi
socketHandler(io, db);

// Sunucuyu başlat
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
    console.log(`🚀 Sunucu ${PORT} portunda çalışıyor`);
    console.log(`📡 WebSocket sunucusu hazır`);
    console.log(`🌍 Ortam: ${process.env.NODE_ENV || 'development'}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM sinyali alındı. Sunucu kapatılıyor...');
    server.close(() => {
        console.log('HTTP sunucusu kapatıldı');
        db.close(() => {
            console.log('Veritabanı bağlantısı kapatıldı');
            process.exit(0);
        });
    });
});

module.exports = { app, server, io };