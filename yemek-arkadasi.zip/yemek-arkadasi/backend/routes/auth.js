/**
 * Authentication Routes
 * @description Kullanıcı kayıt, giriş ve şifre işlemleri
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const { registerValidation, loginValidation } = require('../middleware/validation');

/**
 * @route   POST /api/auth/register
 * @desc    Yeni kullanıcı kaydı
 * @access  Public
 */
router.post('/register', registerValidation, async (req, res, next) => {
    try {
        const { email, phone, password, full_name, age, gender } = req.body;

        // E-posta veya telefon kontrolü
        const existingUser = await db.queryOne(
            'SELECT id FROM users WHERE email = ? OR phone = ?',
            [email, phone]
        );

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: 'Bu e-posta veya telefon numarası zaten kayıtlı'
            });
        }

        // Şifreyi hashle
        const saltRounds = 12;
        const password_hash = await bcrypt.hash(password, saltRounds);

        // Transaction başlat
        await db.beginTransaction();

        try {
            // Kullanıcıyı oluştur
            const userResult = await db.run(
                `INSERT INTO users (email, phone, password_hash, full_name, age, gender, verification_level)
                 VALUES (?, ?, ?, ?, ?, ?, 'bronze')`,
                [email, phone, password_hash, full_name, age, gender]
            );

            const userId = userResult.lastID;

            // Profil tablosunu oluştur
            await db.run(
                `INSERT INTO profiles (user_id) VALUES (?)`,
                [userId]
            );

            // Telefon doğrulama kaydı oluştur
            await db.run(
                `INSERT INTO verifications (user_id, type, status) VALUES (?, 'phone', 'pending')`,
                [userId]
            );

            // E-posta doğrulama kaydı oluştur
            await db.run(
                `INSERT INTO verifications (user_id, type, status) VALUES (?, 'email', 'pending')`,
                [userId]
            );

            await db.commit();

            // JWT token oluştur
            const token = jwt.sign(
                { userId, email },
                process.env.JWT_SECRET || 'yemek-arkadasi-secret-key-2024',
                { expiresIn: '30d' }
            );

            res.status(201).json({
                success: true,
                message: 'Kayıt başarılı! Lütfen e-posta ve telefonunuzu doğrulayın.',
                data: {
                    token,
                    user: {
                        id: userId,
                        email,
                        phone,
                        full_name,
                        age,
                        gender,
                        verification_level: 'bronze'
                    }
                }
            });

        } catch (error) {
            await db.rollback();
            throw error;
        }

    } catch (error) {
        next(error);
    }
});

/**
 * @route   POST /api/auth/login
 * @desc    Kullanıcı girişi
 * @access  Public
 */
router.post('/login', loginValidation, async (req, res, next) => {
    try {
        const { identifier, password } = req.body;

        // E-posta veya telefon ile kullanıcıyı bul
        const user = await db.queryOne(
            `SELECT id, email, phone, password_hash, full_name, verification_level, 
                    rating_average, total_meals, is_active, avatar_url
             FROM users 
             WHERE (email = ? OR phone = ?) AND is_active = 1`,
            [identifier, identifier]
        );

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Geçersiz e-posta/telefon veya şifre'
            });
        }

        // Şifreyi kontrol et
        const isPasswordValid = await bcrypt.compare(password, user.password_hash);

        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'Geçersiz e-posta/telefon veya şifre'
            });
        }

        // Hassas bilgileri çıkar
        delete user.password_hash;

        // JWT token oluştur
        const token = jwt.sign(
            { userId: user.id, email: user.email },
            process.env.JWT_SECRET || 'yemek-arkadasi-secret-key-2024',
            { expiresIn: '30d' }
        );

        res.json({
            success: true,
            message: 'Giriş başarılı',
            data: {
                token,
                user
            }
        });

    } catch (error) {
        next(error);
    }
});

/**
 * @route   POST /api/auth/logout
 * @desc    Kullanıcı çıkışı (client-side token silme)
 * @access  Private
 */
router.post('/logout', (req, res) => {
    res.json({
        success: true,
        message: 'Çıkış başarılı'
    });
});

/**
 * @route   POST /api/auth/refresh-token
 * @desc    Token yenileme
 * @access  Public
 */
router.post('/refresh-token', async (req, res, next) => {
    try {
        const { refreshToken } = req.body;

        if (!refreshToken) {
            return res.status(400).json({
                success: false,
                message: 'Refresh token gerekli'
            });
        }

        // Refresh token'ı doğrula
        const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'refresh-secret-key-2024');

        // Kullanıcıyı kontrol et
        const user = await db.queryOne(
            `SELECT id, email, is_active FROM users WHERE id = ? AND is_active = 1`,
            [decoded.userId]
        );

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Geçersiz refresh token'
            });
        }

        // Yeni access token oluştur
        const newToken = jwt.sign(
            { userId: user.id, email: user.email },
            process.env.JWT_SECRET || 'yemek-arkadasi-secret-key-2024',
            { expiresIn: '30d' }
        );

        res.json({
            success: true,
            data: {
                token: newToken
            }
        });

    } catch (error) {
        if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Geçersiz veya süresi dolmuş refresh token'
            });
        }
        next(error);
    }
});

/**
 * @route   POST /api/auth/forgot-password
 * @desc    Şifre sıfırlama e-postası gönder
 * @access  Public
 */
router.post('/forgot-password', async (req, res, next) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'E-posta adresi gerekli'
            });
        }

        const user = await db.queryOne(
            'SELECT id FROM users WHERE email = ? AND is_active = 1',
            [email]
        );

        // Kullanıcı bulunmasa bile başarılı mesajı dön (güvenlik)
        if (!user) {
            return res.json({
                success: true,
                message: 'Şifre sıfırlama bağlantısı e-posta adresinize gönderildi'
            });
        }

        // TODO: Şifre sıfırlama token'ı oluştur ve e-posta gönder
        // Şimdilik simülasyon

        res.json({
            success: true,
            message: 'Şifre sıfırlama bağlantısı e-posta adresinize gönderildi'
        });

    } catch (error) {
        next(error);
    }
});

/**
 * @route   POST /api/auth/reset-password
 * @desc    Şifre sıfırlama
 * @access  Public
 */
router.post('/reset-password', async (req, res, next) => {
    try {
        const { token, newPassword } = req.body;

        if (!token || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Token ve yeni şifre gerekli'
            });
        }

        // Şifre validasyonu
        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                message: 'Şifre en az 8 karakter olmalıdır'
            });
        }

        // TODO: Token'ı doğrula ve şifreyi güncelle
        // Şimdilik simülasyon

        res.json({
            success: true,
            message: 'Şifreniz başarıyla güncellendi'
        });

    } catch (error) {
        next(error);
    }
});

module.exports = router;